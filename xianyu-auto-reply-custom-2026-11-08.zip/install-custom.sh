#!/usr/bin/env bash
# ==========================================
# 闲鱼自动回复系统 - 自定义版本安装 / 升级脚本
#
# 用法：
#   bash install-custom.sh                     # 备份 → 构建 → 启动
#   bash install-custom.sh --skip-build        # 不重新构建，直接用现有镜像重启
#   bash install-custom.sh --load-images x.tar # 先加载离线镜像，再启动
#   bash install-custom.sh --no-backup         # 跳过备份（不推荐）
#
# 特性：
# 1. 自动识别「官方镜像升级」与「全新部署」两种场景
# 2. 保留 .env 和 ./xianyu_auto_reply 下的 MySQL/Redis 数据
# 3. 构建前给旧镜像打 :prev 标签，可用 rollback-custom.sh 回滚
# ==========================================

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

WORK_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$WORK_DIR"

COMPOSE_FILE="$WORK_DIR/docker-compose.custom.yml"
ENV_FILE="$WORK_DIR/.env"
PROJECT_NAME="xianyu-auto-reply"
APP_SERVICES=(backend-web websocket scheduler frontend)
APP_IMAGES=(xianyu-custom-backend-web xianyu-custom-websocket xianyu-custom-scheduler xianyu-custom-frontend)
MYSQL_CONTAINER="xianyu-mysql"

DO_BACKUP=1
DO_BUILD=1
LOAD_IMAGES=""

while [ $# -gt 0 ]; do
    case "$1" in
        --no-backup) DO_BACKUP=0 ;;
        --skip-build) DO_BUILD=0 ;;
        --load-images)
            shift
            LOAD_IMAGES="${1:-}"
            [ -n "$LOAD_IMAGES" ] || { echo -e "${RED}--load-images 需要指定 tar 文件${NC}"; exit 1; }
            DO_BUILD=0
            ;;
        -h|--help)
            sed -n '2,18p' "$0"
            exit 0
            ;;
        *)
            echo -e "${RED}未知参数: $1${NC}"
            exit 1
            ;;
    esac
    shift
done

echo "=========================================="
echo "  闲鱼自动回复系统 - 自定义版安装/升级"
echo "=========================================="

# ---------- 环境检查 ----------
if ! command -v docker >/dev/null 2>&1; then
    echo -e "${RED}错误：未安装 Docker${NC}"
    exit 1
fi
if docker compose version >/dev/null 2>&1; then
    DC=(docker compose)
elif command -v docker-compose >/dev/null 2>&1; then
    DC=(docker-compose)
else
    echo -e "${RED}错误：未安装 Docker Compose${NC}"
    exit 1
fi
if [ ! -f "$COMPOSE_FILE" ]; then
    echo -e "${RED}错误：缺少 docker-compose.custom.yml，请在完整解压后的目录执行${NC}"
    exit 1
fi

export COMPOSE_PROJECT_NAME="$PROJECT_NAME"
DC_CMD=("${DC[@]}" -f "$COMPOSE_FILE")

# ---------- .env ----------
if [ ! -f "$ENV_FILE" ]; then
    echo -e "${YELLOW}[提示] 未找到 .env，生成默认配置${NC}"
    cat > "$ENV_FILE" <<'ENVEOF'
MYSQL_ROOT_PASSWORD=xianyu@2026
MYSQL_DATABASE=xianyu_data
MYSQL_USER=xianyu
MYSQL_PASSWORD=xianyu@2026
REDIS_PASSWORD=xianyu@2026
REDIS_DB=0
FRONTEND_PORT=9000
BACKEND_WEB_PORT=8089
WEBSOCKET_PORT=8090
SCHEDULER_PORT=8091
LOG_LEVEL=INFO
SQL_ECHO=false
ACCESS_TOKEN_EXPIRE_MINUTES=1440
REFRESH_TOKEN_EXPIRE_MINUTES=10080
REDELIVERY_INTERVAL=5
RATE_INTERVAL=20
MAX_CAPTCHA_CONCURRENT=3
AUTO_START_WEBSOCKET=true
TZ=Asia/Shanghai
ENVEOF
fi
DC_CMD+=("--env-file" "$ENV_FILE")

read_env() {
    local key="$1" default="$2"
    local value
    value="$(grep -E "^${key}=" "$ENV_FILE" 2>/dev/null | tail -n 1 | cut -d '=' -f2- | tr -d '\r' || true)"
    printf '%s' "${value:-$default}"
}

MYSQL_ROOT_PASSWORD="$(read_env MYSQL_ROOT_PASSWORD 'xianyu@2026')"
MYSQL_DATABASE="$(read_env MYSQL_DATABASE 'xianyu_data')"
BACKEND_WEB_PORT="$(read_env BACKEND_WEB_PORT '8089')"

# ---------- 模式识别 ----------
DATA_DIR="$WORK_DIR/xianyu_auto_reply/mysql/data"
if [ -d "$DATA_DIR" ] && [ -n "$(ls -A "$DATA_DIR" 2>/dev/null || true)" ]; then
    MODE="升级（保留现有 MySQL 数据）"
else
    MODE="全新部署（初始化空数据库）"
fi
echo -e "${CYAN}[信息] 部署目录：$WORK_DIR${NC}"
echo -e "${CYAN}[信息] 模式：$MODE${NC}"

# ---------- 创建挂载目录 ----------
mkdir -p \
    "$WORK_DIR/xianyu_auto_reply/mysql/data" \
    "$WORK_DIR/xianyu_auto_reply/redis/data" \
    "$WORK_DIR/xianyu_auto_reply/logs/backend_web" \
    "$WORK_DIR/xianyu_auto_reply/logs/websocket" \
    "$WORK_DIR/xianyu_auto_reply/logs/scheduler" \
    "$WORK_DIR/xianyu_auto_reply/static" \
    "$WORK_DIR/xianyu_auto_reply/backups" \
    "$WORK_DIR/xianyu_auto_reply/browser_data"

# ---------- 备份 ----------
if [ "$DO_BACKUP" -eq 1 ]; then
    BK_DIR="$WORK_DIR/backups/pre-custom-$(date +%Y%m%d-%H%M%S)"
    mkdir -p "$BK_DIR"
    echo -e "${YELLOW}[1/4] 备份配置与数据库到 $BK_DIR ...${NC}"
    cp -f "$ENV_FILE" "$BK_DIR/" 2>/dev/null || true
    [ -f "$WORK_DIR/docker-compose.deploy.yml" ] && cp -f "$WORK_DIR/docker-compose.deploy.yml" "$BK_DIR/" || true

    if docker ps --format '{{.Names}}' | grep -q "^${MYSQL_CONTAINER}$"; then
        if docker exec -e MYSQL_PWD="$MYSQL_ROOT_PASSWORD" "$MYSQL_CONTAINER" \
            mysqldump -uroot --single-transaction --routines --triggers "$MYSQL_DATABASE" \
            > "$BK_DIR/db.sql" 2>"$BK_DIR/db_dump.err"; then
            echo -e "${GREEN}  ✓ 数据库已导出：$BK_DIR/db.sql${NC}"
        else
            echo -e "${YELLOW}  ! 数据库导出失败，请查看 $BK_DIR/db_dump.err${NC}"
        fi
    else
        echo -e "${YELLOW}  ! MySQL 容器未运行，跳过数据库导出${NC}"
    fi

    if [ -d "$WORK_DIR/xianyu_auto_reply" ]; then
        tar czf "$BK_DIR/xianyu_auto_reply.tar.gz" \
            --exclude='xianyu_auto_reply/static/uploads' \
            -C "$WORK_DIR" xianyu_auto_reply 2>/dev/null \
            && echo -e "${GREEN}  ✓ 数据目录已打包（不含 uploads）：$BK_DIR/xianyu_auto_reply.tar.gz${NC}" \
            || echo -e "${YELLOW}  ! 数据目录打包失败（不影响继续）${NC}"
    fi
else
    echo -e "${YELLOW}[1/4] 已跳过备份${NC}"
fi

# ---------- 给旧镜像打回滚标签 ----------
echo -e "${YELLOW}[2/4] 记录旧镜像（:prev）...${NC}"
for image in "${APP_IMAGES[@]}"; do
    if docker image inspect "${image}:latest" >/dev/null 2>&1; then
        docker tag "${image}:latest" "${image}:prev"
        echo "  ✓ ${image}:latest -> :prev"
    fi
done

# ---------- 加载离线镜像 ----------
if [ -n "$LOAD_IMAGES" ]; then
    echo -e "${YELLOW}[3/4] 加载离线镜像：$LOAD_IMAGES ...${NC}"
    docker load -i "$LOAD_IMAGES"
elif [ "$DO_BUILD" -eq 1 ]; then
    echo -e "${YELLOW}[3/4] 从源码构建镜像（首次约 10-30 分钟）...${NC}"
    echo -e "${CYAN}  提示：构建需要访问 Docker Hub / 基础镜像源，国内服务器请先配置代理${NC}"
    "${DC_CMD[@]}" build "${APP_SERVICES[@]}"
else
    echo -e "${YELLOW}[3/4] 跳过构建，使用现有 xianyu-custom-* 镜像${NC}"
fi

# ---------- 启动 ----------
echo -e "${YELLOW}[4/4] 启动服务...${NC}"
"${DC_CMD[@]}" up -d

echo ""
echo "等待后端健康检查（最多 150 秒）..."
HEALTHY=0
for _ in $(seq 1 30); do
    if curl -fsS "http://127.0.0.1:${BACKEND_WEB_PORT}/health" >/dev/null 2>&1; then
        HEALTHY=1
        break
    fi
    sleep 5
done

echo ""
"${DC_CMD[@]}" ps

if [ "$HEALTHY" -eq 1 ]; then
    echo ""
    echo -e "${GREEN}=========================================="
    echo "  部署成功"
    echo -e "==========================================${NC}"
    echo "  前端：      http://<服务器IP>:$(read_env FRONTEND_PORT '9000')"
    echo "  API 文档：  http://<服务器IP>:${BACKEND_WEB_PORT}/docs"
    echo "  素材库：    商品发布 → 素材库（导入/导出/加水印/拷贝商品）"
    echo "  水印设置：  系统设置 → 水印设置"
else
    echo ""
    echo -e "${RED}后端健康检查未通过，请查看日志：${NC}"
    echo "  ${DC[@]:0:2} -f docker-compose.custom.yml logs --tail=200 backend-web"
    echo ""
    echo -e "${YELLOW}如需回滚：bash rollback-custom.sh${NC}"
    exit 1
fi
