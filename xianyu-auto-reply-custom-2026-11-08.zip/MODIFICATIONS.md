# 修改说明（相对上游）

- **上游项目**：xianyu-auto-reply
- **上游仓库**：https://github.com/zhinianboke/xianyu-auto-reply
- **上游版本**：20260919
- **本仓库性质**：非官方衍生修改版，由第三方基于上游源码修改，**与原作者无关，不代表原作者观点**
- **修改日期**：2026-11-08
- **许可证**：GNU Affero General Public License v3.0（沿用上游 `LICENSE`，未更改）

## 修改内容

1. **素材库：Excel 导入 / 导出**
   - 新增 `POST /api/v1/product-publish/materials/export`、`/import`
   - 图片、视频、规格、SKU、平台分类等嵌套字段以 JSON 文本保存，可完整往返
   - 前端素材库新增「导入素材 / 导出素材」按钮与导入弹窗

2. **商品监控：拷贝商品**
   - 新增「拷贝商品」入口：粘贴闲鱼商品链接，自动采集标题、描述、价格、图片并存入素材库
   - 默认匿名解析（无需登录闲鱼账号），失败时自动回退到已登录账号
   - 图片下载到本地 `static/uploads/products/`，保留原图

3. **素材库：图片水印**
   - 批量加水印（整图平铺）与单条水印两种模式
   - 系统设置新增「水印设置」：内容、字号、颜色、透明度、旋转角度、位置
   - 去水印接口为半成品，仅预留 AI 接口配置

4. **本地开发修复**
   - 修复 uvicorn `--reload` 在 Windows 控制台输出时失效的问题（重定向日志后热重载正常）

5. **Docker**
   - `backend-web/Dockerfile` 增加 `fonts-wqy-zenhei`，保证容器内中文水印正常渲染

6. **部署**
   - 新增 `docker-compose.custom.yml`、`install-custom.sh`、`rollback-custom.sh`、`部署说明.md`

## 修改文件清单

```text
backend-web/app/services/material_transfer_service.py       新增
backend-web/app/services/material_copy_service.py           新增
backend-web/app/services/image_watermark_service.py          新增
backend-web/app/api/routes/product_publish.py                修改
backend-web/Dockerfile                                       修改
frontend/src/api/productPublish.ts                           修改
frontend/src/pages/product-publish/ProductMaterials.tsx      修改
frontend/src/pages/product-publish/WatermarkModal.tsx        新增
frontend/src/pages/product-monitor/CopyItemModal.tsx         新增
frontend/src/pages/product-monitor/ListingMonitor.tsx        修改
frontend/src/pages/settings/WatermarkSettingsCard.tsx        新增
frontend/src/pages/settings/Settings.tsx                     修改
docker-compose.custom.yml                                    新增
install-custom.sh / rollback-custom.sh                       新增
```

## 许可证与义务

本项目沿用上游 **AGPL-3.0**：

- 分发本软件或其修改版时，必须保留 `LICENSE` 与版权声明，并继续使用 AGPL-3.0
- 必须标明对原作品的修改（即本文档）
- 若通过网络向用户提供服务，应按 AGPL 第 13 条向这些用户提供对应的完整源码
- 不得移除或替换上游的许可证与作者署名
