@echo off
chcp 65001 >nul
cd /d "%~dp0"

where git >nul 2>&1
if errorlevel 1 (
    echo [错误] 未安装 Git，请先安装：https://git-scm.com/download/win
    pause
    exit /b 1
)

if not exist ".git" (
    git init
)

set "EMAIL="
for /f "delims=" %%i in ('git config user.email 2^>nul') do set "EMAIL=%%i"
if "%EMAIL%"=="" (
    set /p "NAME=请输入提交作者名称："
    set /p "EMAIL=请输入邮箱："
    git config user.name "%NAME%"
    git config user.email "%EMAIL%"
)

echo.
echo 正在检查敏感文件...
if exist ".env" (
    echo [警告] 发现 .env，未加入 .gitignore 前请先删除或确认不会被提交
)
git add .
git status --short | findstr /i ".env xianyu_auto_reply uploads backups node_modules .venv" && (
    echo.
    echo [警告] 暂存区包含疑似敏感文件，请检查后重新执行。
    pause
    exit /b 1
)

git commit -m "feat: 素材库导入导出、拷贝商品、图片水印（基于上游 20260919）"
if errorlevel 1 echo [提示] 没有需要提交的新改动，继续推送。

git branch -M main

echo.
set /p "REPO=请输入 GitHub 仓库地址（https://github.com/用户名/仓库.git）："
if "%REPO%"=="" (
    echo [错误] 仓库地址为空
    pause
    exit /b 1
)

git remote remove origin >nul 2>&1
git remote add origin %REPO%
echo.
echo 正在推送...
git push -u origin main
if errorlevel 1 (
    echo.
    echo [失败] 推送失败。请确认仓库已在 GitHub 创建，且已登录 GitHub 账号。
) else (
    echo.
    echo [成功] 已推送到 %REPO%
)
pause
