"""
闲鱼IM WebSocket客户端

功能：
1. 通过mtop API获取IM登录Token
2. 建立WebSocket连接并注册
3. 获取会话列表 (/r/Conversation/listNewestPagination)
4. 获取聊天记录 (/r/MessageManager/listUserMessages)
5. 心跳保活与自动ACK

参照 goofish-client 和 XianYuApis-master 实现
"""
import asyncio
import base64
import json
import time
from typing import Any, Dict, List, Optional

import aiohttp
from loguru import logger
from sqlalchemy import text

from app.services.websocket_client import websocket_client
from common.db.session import async_session_maker
from common.utils.cookie_refresh import (
    merge_cookies,
    update_account_cookies_in_db,
)
from common.services.captcha.token_response import is_token_expired_response
from common.services.im_token_api import (
    extract_im_access_token,
    request_im_token_with_fallback,
)
from common.services.token_renewal_cache_service import (
    mark_token_cache_expired,
    upsert_token_cache,
)
from common.services.token_api_mode import (
    get_token_api_mode_label,
    load_token_api_mode,
)
from common.utils.time_utils import get_beijing_now_naive
from common.utils.xianyu_utils import (
    generate_device_id,
    generate_mid,
    generate_uuid,
    trans_cookies,
)


# WebSocket连接地址
WS_URL = "wss://wss-goofish.dingtalk.com/"
# 请求超时（秒）
REQUEST_TIMEOUT = 20
# 心跳间隔（秒）
HEARTBEAT_INTERVAL = 15
# 风控滑块验证关键词：Token响应中出现任一关键词即表示被风控拦截（如"哎哟喂,被挤爆啦"），需过滑块
# 与 websocket 进程 cookie_token_manager.need_captcha_verification 保持一致
CAPTCHA_KEYWORDS = (
    "FAIL_SYS_USER_VALIDATE",  # 用户验证失败
    "RGV587_ERROR",            # 风控错误
    "哎哟喂,被挤爆啦",          # 被挤爆了（英文逗号）
    "哎哟喂，被挤爆啦",         # 被挤爆了（中文逗号）
    "挤爆了",                  # 被挤爆了
    "请稍后重试",              # 请稍后重试
    "punish?x5secdata",        # 惩罚页面
    "captcha",                 # 验证码
)
# 过滑块重试上限（防止无限递归）
CAPTCHA_MAX_RETRY = 1
# 被判定为「连接/Token 失效」的 LWP 响应码：此类响应无 body，仅有 code。
# 闲鱼对 token 过期或注册态失效的请求统一返回 400，需要换新 token 重连才能恢复。
TOKEN_INVALID_LWP_CODES = (400,)


class ImRequestRejected(Exception):
    """IM LWP 请求被服务端拒绝（响应 code 非 200 且不带 body）

    携带服务端返回的 code，供上层区分「Token/连接失效(400)」与其它拒绝原因。
    继承 Exception，原有 `except Exception` 的调用方行为不变。
    """

    def __init__(self, message: str, code: Any):
        super().__init__(message)
        self.code = code


class GoofishImClient:
    """闲鱼IM WebSocket客户端，用于获取会话列表和聊天记录"""

    def __init__(
        self,
        account_id: str,
        cookies_str: str,
        *,
        account_row_id: int | None = None,
    ):
        """
        初始化IM客户端

        Args:
            account_id: 账号ID（数据库account_id）
            cookies_str: Cookie字符串
            account_row_id: 账号数据库行 ID，供滑块成功后精准写回 Cookie
        """
        self.account_id = account_id
        self.account_row_id = account_row_id
        self.cookies_str = cookies_str
        self.cookies: Dict[str, str] = trans_cookies(cookies_str)
        self.myid: str = self.cookies.get("unb", "")
        self.device_id: str = generate_device_id(self.myid)
        self.token: str = ""
        self._captcha_token_cache_saved = False

        # WebSocket相关
        self._ws: Optional[aiohttp.ClientWebSocketResponse] = None
        self._session: Optional[aiohttp.ClientSession] = None
        self._connected: bool = False
        self._registered: bool = False

        # 请求-响应配对
        self._pending: Dict[str, asyncio.Future] = {}
        # 连接代次 + 重连互斥：多个并发请求同时收到 400 时只重连一次，
        # 后到的请求发现代次已变化即直接复用新连接，不再重复断连
        self._conn_generation: int = 0
        self._reconnect_lock: asyncio.Lock = asyncio.Lock()
        # 后台任务
        self._recv_task: Optional[asyncio.Task] = None
        self._heartbeat_task: Optional[asyncio.Task] = None

        # 推送消息回调列表（用于向前端 WebSocket 转发实时消息）
        self._push_callbacks: List = []

    # ==================== 连接管理 ====================

    async def connect(self) -> bool:
        """
        建立连接：获取Token -> 连接WebSocket -> 注册

        Returns:
            是否连接成功
        """
        try:
            # 1. 获取IM Token
            self.token = await self._get_im_token()
            if not self.token:
                logger.error(f"【{self.account_id}】获取IM Token失败")
                return False
            logger.info(f"【{self.account_id}】获取IM Token成功")

            # 2. 建立WebSocket连接
            headers = {
                "Cookie": self.cookies_str,
                "Host": "wss-goofish.dingtalk.com",
                "Connection": "Upgrade",
                "Pragma": "no-cache",
                "Cache-Control": "no-cache",
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/146.0.0.0 Safari/537.36"
                ),
                "Origin": "https://www.goofish.com",
                "Accept-Encoding": "gzip, deflate, br, zstd",
                "Accept-Language": "zh-CN,zh;q=0.9",
            }
            self._session = aiohttp.ClientSession()
            # 超时策略（应对 wss:// 网络抖动）：
            # - total=None:      WebSocket 是长连接，原 total=30 会强制 30 秒后断开整个会话
            # - connect=30:      TCP + SSL/TLS 握手 + 连接池等待的超时（关键！wss 的 TLS 握手由此覆盖）
            # - sock_connect=30: 仅 TCP 三次握手超时（不含 TLS，作为 connect 的兜底）
            # - sock_read=None:  持久 WebSocket 不应有读超时（消息间隔可能很长）
            # - heartbeat=30:    aiohttp 库自身 PING 帧间隔 30 秒（与应用层心跳互补）
            self._ws = await self._session.ws_connect(
                WS_URL,
                headers=headers,
                heartbeat=30,
                timeout=aiohttp.ClientTimeout(
                    total=None,
                    connect=30,
                    sock_connect=30,
                    sock_read=None,
                ),
            )
            self._connected = True
            logger.info(f"【{self.account_id}】WebSocket连接成功")

            # 3. 启动消息接收循环
            self._recv_task = asyncio.create_task(self._recv_loop())

            # 4. 注册
            await self._register()
            self._registered = True
            logger.info(f"【{self.account_id}】IM注册成功")

            # 5. 注册后冷却（防止立即请求触发IM流控 400600001）
            await asyncio.sleep(3)

            # 6. 启动心跳
            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

            return True

        except Exception as e:
            logger.error(f"【{self.account_id}】IM连接失败: {e}")
            await self.disconnect()
            return False

    async def disconnect(self):
        """断开连接，释放资源"""
        self._connected = False
        self._registered = False

        # 取消后台任务
        for task in [self._heartbeat_task, self._recv_task]:
            if task and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

        self._heartbeat_task = None
        self._recv_task = None

        # 拒绝所有待处理请求
        for mid, future in self._pending.items():
            if not future.done():
                future.set_exception(Exception("连接已断开"))
        self._pending.clear()

        # 关闭WebSocket
        if self._ws and not self._ws.closed:
            try:
                await self._ws.close()
            except Exception:
                pass
        self._ws = None

        # 关闭HTTP会话
        if self._session and not self._session.closed:
            try:
                await self._session.close()
            except Exception:
                pass
        self._session = None

        logger.info(f"【{self.account_id}】IM连接已断开")

    @property
    def is_connected(self) -> bool:
        """是否已连接并注册（含底层 ws 真实状态双重检查，避免标志位与实际连接不同步）"""
        return (
            self._connected
            and self._registered
            and self._ws is not None
            and not self._ws.closed
        )

    # ==================== 业务接口 ====================

    async def get_conversations(
        self, start_timestamp: Optional[int] = None, limit: int = 20
    ) -> Dict[str, Any]:
        """
        获取会话列表（含流控自动重试）

        Args:
            start_timestamp: 开始时间戳，首页传None(使用MAX_SAFE_INTEGER)，翻页传nextCursor
            limit: 每页数量

        Returns:
            包含 hasMore, nextCursor, userConvs 的字典
        """
        if start_timestamp is None:
            start_timestamp = 9007199254740991  # Number.MAX_SAFE_INTEGER

        max_retries = 3
        for attempt in range(max_retries):
            def _build():
                mid = generate_mid()
                return mid, {
                    "lwp": "/r/Conversation/listNewestPagination",
                    "headers": {"mid": mid},
                    "body": [start_timestamp, limit],
                }

            # code=400 时会先刷新 Token 重连再重试一次（查询幂等，可安全重试）
            response = await self._send_and_wait_with_retry(_build)
            body = response.get("body", {})

            # 检查是否被流控
            if isinstance(body, dict) and body.get("code") == "400600001":
                wait_sec = (attempt + 1) * 2
                logger.warning(
                    f"【{self.account_id}】会话列表被流控，"
                    f"{wait_sec}秒后重试（{attempt + 1}/{max_retries}）"
                )
                await asyncio.sleep(wait_sec)
                continue

            return body

        # 重试耗尽，返回最后一次结果
        return body

    async def get_messages(
        self,
        cid: str,
        start_timestamp: Optional[int] = None,
        limit: int = 20,
    ) -> Dict[str, Any]:
        """
        获取单个会话的聊天记录

        Args:
            cid: 会话ID（不含@goofish后缀）
            start_timestamp: 开始时间戳，首页传None，翻页传nextCursor
            limit: 每页数量

        Returns:
            包含 hasMore, nextCursor, userMessageModels 的字典
        """
        if start_timestamp is None:
            start_timestamp = 9007199254740991

        # 确保cid带@goofish后缀
        full_cid = cid if "@goofish" in cid else f"{cid}@goofish"

        def _build():
            mid = generate_mid()
            return mid, {
                "lwp": "/r/MessageManager/listUserMessages",
                "headers": {"mid": mid},
                "body": [full_cid, False, start_timestamp, limit, False],
            }

        # code=400 时会先刷新 Token 重连再重试一次（查询幂等，可安全重试）
        response = await self._send_and_wait_with_retry(_build)
        return response.get("body", {})

    async def send_text_message(
        self, cid: str, to_user_id: str, text: str
    ) -> Dict[str, Any]:
        """
        发送文本消息

        参照 XianYuApis-master/goofish_live.py 的 send_msg 实现

        Args:
            cid: 会话ID（不含@goofish后缀）
            to_user_id: 对方用户ID
            text: 消息文本

        Returns:
            IM服务器响应
        """
        full_cid = cid if "@goofish" in cid else f"{cid}@goofish"
        full_to = to_user_id if "@goofish" in to_user_id else f"{to_user_id}@goofish"
        full_self = f"{self.myid}@goofish"

        # 构造文本消息 payload
        payload = {"contentType": 1, "text": {"text": text}}
        data_b64 = base64.b64encode(
            json.dumps(payload).encode("utf-8")
        ).decode("utf-8")

        mid = generate_mid()
        message_uuid = generate_uuid()
        msg = {
            "lwp": "/r/MessageSend/sendByReceiverScope",
            "headers": {"mid": mid},
            "body": [
                {
                    "uuid": message_uuid,
                    "cid": full_cid,
                    "conversationType": 1,
                    "content": {
                        "contentType": 101,
                        "custom": {"type": 1, "data": data_b64},
                    },
                    "redPointPolicy": 0,
                    "extension": {"extJson": "{}"},
                    "ctx": {"appVersion": "1.0", "platform": "web"},
                    "mtags": {},
                    "msgReadStatusSetting": 1,
                },
                {"actualReceivers": [full_to, full_self]},
            ],
        }
        # 发送非幂等：code=400 时只刷新 Token 重连、不自动重发，避免重复发送同一条消息
        response = await self._send_and_wait_with_retry(
            lambda: (mid, msg), retry_after_reconnect=False
        )
        # IM 服务端对违规内容会返回带 reason 的 body（如 CSI_FORBID 安全拦截），
        # 此时虽然响应携带 body 不会在 _send_and_wait 抛错，但消息实际未送达，
        # 需在此识别为发送失败并抛出明文原因，供上层反馈给前端。
        self._raise_if_send_rejected(response)
        # 解析服务端返回的 messageId，供消息撤回功能使用
        body = response.get("body", {})
        message_id = ""
        if isinstance(body, dict):
            raw_message_id = body.get("messageId") or body.get("1")
            if isinstance(raw_message_id, dict):
                raw_message_id = raw_message_id.get("messageId") or raw_message_id.get("1")
            if isinstance(raw_message_id, str):
                message_id = raw_message_id
        return {"response": response, "messageId": message_id, "uuid": message_uuid}

    async def send_image_message(
        self,
        cid: str,
        to_user_id: str,
        image_url: str,
        width: int = 800,
        height: int = 600,
    ) -> Dict[str, Any]:
        """
        发送图片消息

        与 send_text_message 协议一致，仅消息体内容为 contentType=2 的图片结构。
        图片必须是已上传到闲鱼CDN的可访问URL（通过 ImageUploader 上传得到）。

        Args:
            cid: 会话ID（不含@goofish后缀）
            to_user_id: 对方用户ID
            image_url: 闲鱼CDN图片URL
            width: 图片宽度（像素），用于前端按比例渲染
            height: 图片高度（像素）

        Returns:
            包含 response、messageId、uuid 的结果字典
        """
        full_cid = cid if "@goofish" in cid else f"{cid}@goofish"
        full_to = to_user_id if "@goofish" in to_user_id else f"{to_user_id}@goofish"
        full_self = f"{self.myid}@goofish"

        # 构造图片消息 payload（pics 数组格式，与官方协议一致）
        payload = {
            "contentType": 2,
            "image": {
                "pics": [
                    {
                        "height": int(height),
                        "type": 0,
                        "url": image_url,
                        "width": int(width),
                    }
                ]
            },
        }
        data_b64 = base64.b64encode(
            json.dumps(payload, ensure_ascii=False).encode("utf-8")
        ).decode("utf-8")

        mid = generate_mid()
        message_uuid = generate_uuid()
        msg = {
            "lwp": "/r/MessageSend/sendByReceiverScope",
            "headers": {"mid": mid},
            "body": [
                {
                    "uuid": message_uuid,
                    "cid": full_cid,
                    "conversationType": 1,
                    "content": {
                        "contentType": 101,
                        "custom": {"type": 1, "data": data_b64},
                    },
                    "redPointPolicy": 0,
                    "extension": {"extJson": "{}"},
                    "ctx": {"appVersion": "1.0", "platform": "web"},
                    "mtags": {},
                    "msgReadStatusSetting": 1,
                },
                {"actualReceivers": [full_to, full_self]},
            ],
        }
        response = await self._send_and_wait_with_retry(
            lambda: (mid, msg), retry_after_reconnect=False
        )
        # 与文本发送一致，识别安全拦截等业务错误并抛出明文原因
        self._raise_if_send_rejected(response)
        body = response.get("body", {})
        message_id = ""
        if isinstance(body, dict):
            raw_message_id = body.get("messageId") or body.get("1")
            if isinstance(raw_message_id, dict):
                raw_message_id = raw_message_id.get("messageId") or raw_message_id.get("1")
            if isinstance(raw_message_id, str):
                message_id = raw_message_id
        return {"response": response, "messageId": message_id, "uuid": message_uuid}

    async def recall_message(self, message_id: str) -> Dict[str, Any]:
        """通过闲鱼官方 IM 协议撤回一条消息"""
        mid = generate_mid()
        # 撤回同样按非幂等处理：code=400 只重连不自动重发，由用户再点一次撤回
        response = await self._send_and_wait_with_retry(
            lambda: (mid, {
                "lwp": "/r/MessageManager/recallMessage",
                "headers": {"mid": mid},
                "body": [message_id],
            }),
            retry_after_reconnect=False,
        )
        if response.get("code") != 200:
            body = response.get("body", {})
            reason = body.get("reason") if isinstance(body, dict) else ""
            raise RuntimeError(reason or "闲鱼未确认撤回成功")
        return response

    @staticmethod
    def _raise_if_send_rejected(response: Dict[str, Any]) -> None:
        """检查发送响应是否被 IM 服务端拒绝（如安全拦截），是则抛出明文原因

        Args:
            response: IM 服务器返回的完整响应

        Raises:
            Exception: 当响应 body 含 reason（业务错误）时抛出，message 为服务端原因文案
        """
        if not isinstance(response, dict):
            return
        body = response.get("body", {})
        if isinstance(body, dict) and body.get("reason"):
            reason = body.get("reason", "")
            more_info = body.get("moreInfo", "")
            # moreInfo 形如 "CSI_FORBID||安全拦截"，附在原因后便于定位拦截类型
            detail = f"{reason}（{more_info}）" if more_info else reason
            raise Exception(detail)

    # ==================== Token缓存（数据库） ====================
    # 缓存键使用 chat_{myid} 前缀，与自动回复WebSocket的缓存隔离，
    # 避免共用同一token/device_id导致IM服务器踢掉自动回复连接

    @property
    def _cache_user_id(self) -> str:
        """Token缓存键，加chat_前缀与自动回复隔离"""
        return f"chat_{self.myid}"

    async def _get_cached_token(self) -> Optional[Dict[str, str]]:
        """从数据库xy_token_cache获取缓存的token和device_id

        Returns:
            包含token和device_id的字典，不存在或已过期则返回None
        """
        try:
            async with async_session_maker() as session:
                result = await session.execute(
                    text("""
                        SELECT token, device_id, expire_at
                        FROM xy_token_cache
                        WHERE user_id = :user_id
                        LIMIT 1
                    """),
                    {"user_id": self._cache_user_id},
                )
                row = result.fetchone()

                if row:
                    token_val, device_id_val, expire_at = row
                    now = get_beijing_now_naive()
                    if expire_at and expire_at > now:
                        remaining = expire_at - now
                        hours = int(remaining.total_seconds() // 3600)
                        minutes = int((remaining.total_seconds() % 3600) // 60)
                        logger.info(
                            f"【{self.account_id}】Token缓存命中: "
                            f"user_id={self.myid}, "
                            f"剩余有效时间={hours}小时{minutes}分钟"
                        )
                        return {"token": token_val, "device_id": device_id_val}
                    else:
                        logger.info(
                            f"【{self.account_id}】Token缓存已过期: "
                            f"user_id={self.myid}, 过期时间={expire_at}"
                        )
                        await self._mark_cached_token_expired()
                else:
                    logger.info(
                        f"【{self.account_id}】Token缓存未命中: "
                        f"cache_key={self._cache_user_id}"
                    )
        except Exception as e:
            logger.warning(f"【{self.account_id}】获取Token缓存失败: {e}")
        return None

    async def _set_cached_token(self, token_val: str, device_id_val: str):
        """将token和device_id缓存到数据库

        使用 INSERT ... ON DUPLICATE KEY UPDATE 实现插入或更新
        基础过期时间由环境变量 TOKEN_CACHE_TTL_MIN_HOURS / TOKEN_CACHE_TTL_MAX_HOURS 控制，
        再追加 1~5 小时的秒级随机偏移；未配置时最终 TTL 为 6~15 小时

        Args:
            token_val: IM Token
            device_id_val: 设备ID
        """
        cache_write = await upsert_token_cache(
            token_user_id=self._cache_user_id,
            token=token_val,
            device_id=device_id_val,
        )
        if not cache_write.success:
            logger.warning(f"【{self.account_id}】{cache_write.message}")
            return
        logger.info(
            f"【{self.account_id}】Token已缓存到数据库 "
            f"(过期时间={cache_write.expire_at:%Y-%m-%d %H:%M:%S}, "
            f"TTL={cache_write.ttl_hours:.1f}小时)"
        )

    async def _mark_cached_token_expired(self):
        """标记已失效的聊天 Token 缓存，保留历史数据并避免覆盖并发更新。"""
        invalidation = await mark_token_cache_expired(
            token_user_id=self._cache_user_id,
        )
        if invalidation.success:
            logger.info(
                f"【{self.account_id}】{invalidation.message}: "
                f"cache_key={self._cache_user_id}"
            )
        else:
            logger.warning(f"【{self.account_id}】{invalidation.message}")

    # ==================== 内部方法 ====================

    async def _get_im_token(self) -> str:
        """获取IM Token，优先从数据库缓存获取，缓存未命中再调mtop API"""
        # 1. 先从数据库缓存获取
        cached = await self._get_cached_token()
        if cached:
            # 恢复缓存中的device_id，保持一致
            self.device_id = cached["device_id"]
            logger.info(
                f"【{self.account_id}】使用数据库缓存的Token和Device ID"
            )
            return cached["token"]

        # 2. 缓存未命中，调API获取
        token = await self._fetch_im_token_from_api()
        if token:
            if self._captcha_token_cache_saved:
                # 滑块服务端已写入同一聊天缓存，避免重复刷新到期时间。
                self._captcha_token_cache_saved = False
            else:
                await self._set_cached_token(token, self.device_id)
        return token

    async def _fetch_im_token_from_api(
        self, _retry: int = 0, _captcha_retry: int = 0
    ) -> str:
        """
        通过mtop API获取IM登录Token

        令牌过期时会从响应Set-Cookie中提取新Cookie，增量合并后更新到数据库和内存，
        然后使用新Cookie重试一次（最多重试1次，防止无限递归）。

        触发风控滑块（如"哎哟喂,被挤爆啦" / FAIL_SYS_USER_VALIDATE）时，委托 WebSocket
        进程过滑块获取最新Cookie，成功后清缓存并用新Cookie重试（最多重试 CAPTCHA_MAX_RETRY 次）。

        Args:
            _retry: 令牌过期内部重试计数，外部不需要传
            _captcha_retry: 过滑块内部重试计数，外部不需要传
        """
        try:
            # Token 接口方式实时查库，确保系统设置修改后无需重启即可生效。
            api_mode = await load_token_api_mode(self.account_id)
            logger.info(
                f"【{self.account_id}】获取IM Token，使用{get_token_api_mode_label(api_mode)}"
            )
            api_result = await request_im_token_with_fallback(
                self.cookies_str,
                self.device_id,
                api_mode=api_mode,
                timeout_seconds=REQUEST_TIMEOUT,
                log_tag=self.account_id,
            )
            if api_result.device_id and api_result.device_id != self.device_id:
                self.device_id = api_result.device_id
                logger.info(f"【{self.account_id}】已更新远程接口返回的Device ID")
            result = api_result.response_json

            # Token 接口下发的 Cookie 统一写回账号。
            new_cookies = api_result.response_cookies
            if new_cookies:
                merged_str = merge_cookies(self.cookies_str, new_cookies)
                self.cookies_str = merged_str
                self.cookies = trans_cookies(merged_str)
                cookie_saved = await update_account_cookies_in_db(
                    self.account_id,
                    merged_str,
                )
                if cookie_saved:
                    logger.info(
                        f"【{self.account_id}】已合并Token接口下发的 "
                        f"{len(new_cookies)} 个Cookie字段并更新到数据库"
                    )
                else:
                    logger.error(
                        f"【{self.account_id}】Token接口下发的Cookie写回数据库失败"
                    )

            # 检查令牌过期，使用新Cookie重试（最多1次）
            ret = result.get("ret", [])
            ret_str = str(ret)
            if is_token_expired_response(result):
                if _retry < 1:
                    logger.warning(
                        f"【{self.account_id}】令牌过期，已更新Cookie，准备重试获取Token（第{_retry + 1}次）"
                    )
                    return await self._fetch_im_token_from_api(_retry=_retry + 1)
                else:
                    logger.error(f"【{self.account_id}】令牌过期重试已达上限，放弃获取Token")
                    return ""

            # 检查是否触发风控滑块验证（如"哎哟喂,被挤爆啦"），委托过滑块后用新Cookie重试
            if self._is_captcha_required(ret_str, result):
                if _captcha_retry >= CAPTCHA_MAX_RETRY:
                    logger.error(f"【{self.account_id}】过滑块重试已达上限，放弃获取Token")
                    return ""
                if not await self._solve_captcha_via_websocket(result):
                    logger.error(f"【{self.account_id}】过滑块失败，放弃获取Token")
                    return ""
                logger.warning(
                    f"【{self.account_id}】过滑块成功，准备用新Cookie重试获取Token"
                    f"（第{_captcha_retry + 1}次）"
                )
                if self._captcha_token_cache_saved:
                    cached = await self._get_cached_token()
                    if cached:
                        self.device_id = cached["device_id"]
                        logger.info(
                            f"【{self.account_id}】使用WebSocket端已写入的聊天Token缓存"
                        )
                        return cached["token"]
                    logger.warning(
                        f"【{self.account_id}】WebSocket端报告Token缓存写入成功，"
                        "但本地未读取到有效缓存，继续重试Token接口"
                    )
                    self._captcha_token_cache_saved = False
                # 仅确认旧缓存已失效；条件更新不会覆盖其他流程刚写入的新 Token。
                await self._mark_cached_token_expired()
                return await self._fetch_im_token_from_api(
                    _retry=_retry, _captcha_retry=_captcha_retry + 1
                )

            access_token = extract_im_access_token(result) or ""
            if not access_token:
                logger.error(
                    f"【{self.account_id}】Token响应异常: "
                    f"{json.dumps(result, ensure_ascii=False)[:300]}"
                )
            return access_token

        except Exception as e:
            logger.error(f"【{self.account_id}】获取IM Token异常: {e}")
            return ""

    def _is_captcha_required(self, ret_str: str, result: Dict[str, Any]) -> bool:
        """判断Token响应是否触发风控滑块验证（被挤爆 / 风控拦截）

        Args:
            ret_str: 响应 ret 字段的字符串形式
            result: 完整响应字典

        Returns:
            是否需要过滑块
        """
        for keyword in CAPTCHA_KEYWORDS:
            if keyword in ret_str:
                logger.info(f"【{self.account_id}】检测到风控滑块关键词: {keyword}")
                return True
        data = result.get("data", {})
        if isinstance(data, dict):
            url = data.get("url", "") or ""
            if any(flag in url for flag in ("punish", "captcha", "validate")):
                logger.info(f"【{self.account_id}】检测到风控验证URL")
                return True
        return False

    async def _solve_captcha_via_websocket(self, result: Dict[str, Any]) -> bool:
        """委托 WebSocket 进程过滑块，成功后合并新Cookie并写回数据库与内存

        backend-web 进程不具备本地浏览器过滑块能力（浏览器持久化目录与账号级互斥锁
        统一收敛在 WebSocket 进程），因此通过 HTTP 委托 /internal/captcha/solve 完成。
        过滑块成功返回的 x5sec 等风控Cookie会合并进当前实例并更新数据库，供本次重试使用。

        Args:
            result: Token接口返回的完整响应字典（含 data.url 验证链接）

        Returns:
            是否过滑块成功（成功时已更新 self.cookies / self.cookies_str / 数据库）
        """
        # 提取 punish 验证链接
        verification_url = ""
        data = result.get("data", {})
        if isinstance(data, dict):
            verification_url = data.get("url", "") or ""
        if not verification_url:
            logger.error(f"【{self.account_id}】未找到验证URL，无法过滑块")
            return False

        logger.info(
            f"【{self.account_id}】检测到风控，委托WebSocket过滑块: {verification_url[:80]}..."
        )
        self._captcha_token_cache_saved = False
        # 携带当前Cookie与设备ID：验证链接过期时 WebSocket 端可凭此重取新鲜链接
        resp = await websocket_client.solve_captcha(
            account_id=self.account_id,
            url=verification_url,
            call_type="local",
            cookies=self.cookies_str,
            device_id=self.device_id,
            account_row_id=self.account_row_id,
            token_user_id=self._cache_user_id,
            persist_token_cache=True,
            token_cache_write_mode="upsert",
        )

        if not (isinstance(resp, dict) and resp.get("success")):
            msg = resp.get("message", "") if isinstance(resp, dict) else ""
            logger.error(f"【{self.account_id}】过滑块失败: {msg}")
            return False

        response_data = resp.get("data")
        if not isinstance(response_data, dict):
            response_data = {}
        raw_cookies = response_data.get("cookies")
        new_cookies = raw_cookies if isinstance(raw_cookies, dict) else {}
        token_already_available = bool(response_data.get("token_already_available"))
        cookie_saved_by_websocket = bool(response_data.get("cookie_saved"))
        self._captcha_token_cache_saved = bool(response_data.get("token_cache_saved"))
        if not new_cookies and not token_already_available:
            logger.error(f"【{self.account_id}】过滑块返回成功但未获取到Cookie，判定为失败")
            return False

        if new_cookies:
            # 合并过滑块返回的Cookie（主要为 x5sec 等风控字段）并写回内存与数据库
            merged_cookies = {**self.cookies, **new_cookies}
            merged_cookies_str = "; ".join(
                f"{key}={value}" for key, value in merged_cookies.items()
            )
            if not cookie_saved_by_websocket:
                saved = await update_account_cookies_in_db(
                    self.account_id,
                    merged_cookies_str,
                )
                if not saved:
                    logger.error(f"【{self.account_id}】过滑块Cookie合并写回数据库失败")
                    return False
            self.cookies = merged_cookies
            self.cookies_str = merged_cookies_str
            logger.info(
                f"【{self.account_id}】过滑块成功，已合并 {len(new_cookies)} 个Cookie，"
                f"数据库写入方={'WebSocket端' if cookie_saved_by_websocket else '聊天端'}"
            )
        if token_already_available:
            logger.info(f"【{self.account_id}】重取验证链接时Token已可用，准备重试Token接口")
        return True

    async def _register(self):
        """发送注册消息 (/reg) 并等待服务器确认，然后发送 ackDiff"""
        # 发送 /reg 并等待响应
        reg_mid = generate_mid()
        reg_msg = {
            "lwp": "/reg",
            "headers": {
                "cache-header": "app-key token ua wv",
                "app-key": "444e9908a51d1cb236a27862abc769c9",
                "token": self.token,
                "ua": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/146.0.0.0 Safari/537.36 "
                    "DingTalk(2.1.5) OS(Windows/10) "
                    "Browser(Chrome/146.0.0.0) DingWeb/2.1.5 "
                    "IMPaaS DingWeb/2.1.5"
                ),
                "dt": "j",
                "wv": "im:3,au:3,sy:6",
                "sync": "0,0;0;0;",
                "did": self.device_id,
                "mid": reg_mid,
            },
        }

        try:
            reg_response = await self._send_and_wait(reg_mid, reg_msg, timeout=5)
            reg_code = reg_response.get("code", 0)
            logger.info(
                f"【{self.account_id}】注册响应: code={reg_code}, "
                f"body={json.dumps(reg_response.get('body', {}), ensure_ascii=False)[:200]}"
            )
            if reg_code != 200:
                logger.warning(f"【{self.account_id}】注册返回非200: {reg_code}")
        except Exception as e:
            logger.warning(f"【{self.account_id}】等待注册响应异常: {e}，继续尝试")

        # 发送 ackDiff
        current_time = int(time.time() * 1000)
        ack_mid = generate_mid()
        ack_msg = {
            "lwp": "/r/SyncStatus/ackDiff",
            "headers": {"mid": ack_mid},
            "body": [
                {
                    "pipeline": "sync",
                    "tooLong2Tag": "PNM,1",
                    "channel": "sync",
                    "topic": "sync",
                    "highPts": 0,
                    "pts": current_time * 1000,
                    "seq": 0,
                    "timestamp": current_time,
                }
            ],
        }
        await self._send_raw(ack_msg)

        # 等待同步完成
        await asyncio.sleep(1)

    async def _send_raw(self, msg: dict):
        """直接发送消息（不等待响应）"""
        if not self._ws or self._ws.closed:
            raise Exception("WebSocket未连接")
        await self._ws.send_json(msg)

    async def _send_and_wait(
        self, mid: str, msg: dict, timeout: float = REQUEST_TIMEOUT
    ) -> dict:
        """
        发送消息并等待匹配mid的响应

        Args:
            mid: 消息ID
            msg: 消息内容
            timeout: 超时秒数

        Returns:
            响应消息字典
        """
        if not self._ws or self._ws.closed:
            raise Exception("WebSocket未连接")

        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()
        self._pending[mid] = future

        try:
            await self._ws.send_json(msg)
            result = await asyncio.wait_for(future, timeout=timeout)
            return result
        except asyncio.TimeoutError:
            raise Exception(f"请求超时: {msg.get('lwp', 'unknown')}")
        finally:
            self._pending.pop(mid, None)

    async def _reconnect_with_new_token(self, seen_generation: int) -> bool:
        """Token/连接失效时：标记 Token 缓存过期 → 断开 → 用新 Token 重新连接并注册

        Token 只在建连的 /reg 头里使用一次，因此换 Token 必须重建连接才生效。
        `_mark_cached_token_expired` 会把 xy_token_cache 的到期时间置为过去，
        使 `_get_im_token` 缓存未命中、必然重新调 API 取一个全新 Token。

        Args:
            seen_generation: 调用方发起请求时记录的连接代次，用于并发去重
        Returns:
            是否已具备可用连接（已由其它请求完成重连时也返回 True）
        """
        async with self._reconnect_lock:
            # 已有其它并发请求完成重连：直接复用新连接，不重复断连
            if self._conn_generation != seen_generation:
                logger.info(f"【{self.account_id}】IM 连接已被其它请求重建，直接复用")
                return self.is_connected

            logger.warning(
                f"【{self.account_id}】IM 请求被拒(code=400)，判定 Token/连接失效，"
                f"标记 Token 缓存过期并重连"
            )
            try:
                await self._mark_cached_token_expired()
            except Exception as e:
                logger.warning(f"【{self.account_id}】标记 Token 缓存过期失败（继续重连）: {e}")

            self.token = ""
            await self.disconnect()
            ok = await self.connect()
            if ok:
                self._conn_generation += 1
                logger.info(f"【{self.account_id}】IM 已用新 Token 重连成功")
            else:
                logger.error(f"【{self.account_id}】IM 重连失败，请稍后在界面重新连接该账号")
            return ok

    async def _send_and_wait_with_retry(
        self,
        build_msg,
        *,
        timeout: float = REQUEST_TIMEOUT,
        retry_after_reconnect: bool = True,
    ) -> dict:
        """发送 LWP 请求；遇到 code=400（Token/连接失效）时刷新 Token 重连

        除自身收到 code=400 外，还处理「并发请求已把连接重连」的情况：本次请求可能
        被那次 disconnect() 以「连接已断开」中断（非 ImRequestRejected），此时按同样的
        连接失效语义处理，避免把一次自愈重连暴露成对用户的报错。

        Args:
            build_msg: 无参回调，返回 (mid, msg)。重试时会重新调用以生成新的 mid
            timeout: 单次请求等待响应的超时秒数
            retry_after_reconnect: 重连成功后是否自动重试。
                幂等查询（会话列表/聊天记录）传 True；
                发送/撤回等非幂等操作传 False，只重连不重发，避免重复发送
        Returns:
            响应消息字典
        Raises:
            ImRequestRejected: 非 400 拒绝、重连失败、或不允许自动重试时抛出
            Exception: 与连接失效无关的错误（超时等）原样抛出
        """
        seen_generation = self._conn_generation
        mid, msg = build_msg()
        try:
            return await self._send_and_wait(mid, msg, timeout=timeout)
        except Exception as e:
            is_token_400 = (
                isinstance(e, ImRequestRejected) and e.code in TOKEN_INVALID_LWP_CODES
            )
            # 本次请求期间代次已变 → 有并发请求完成了重连，当前失败极可能是被那次断连中断
            concurrent_reconnected = self._conn_generation != seen_generation
            if not is_token_400 and not concurrent_reconnected:
                raise
            # is_token_400 → 由本请求触发重连；concurrent_reconnected → _reconnect 内部发现
            # 代次已变会直接复用新连接、不再重复断连
            if not await self._reconnect_with_new_token(seen_generation):
                raise
            if not retry_after_reconnect:
                code = e.code if isinstance(e, ImRequestRejected) else None
                raise ImRequestRejected(
                    f"连接已失效，已自动重连（原因: {e}），请重新操作一次", code
                ) from e
            logger.info(f"【{self.account_id}】重连完成，重试 {msg.get('lwp', 'unknown')}")
            mid, msg = build_msg()
            return await self._send_and_wait(mid, msg, timeout=timeout)

    async def _recv_loop(self):
        """后台消息接收循环"""
        try:
            async for ws_msg in self._ws:
                if ws_msg.type == aiohttp.WSMsgType.TEXT:
                    await self._handle_message(ws_msg.data)
                elif ws_msg.type in (
                    aiohttp.WSMsgType.CLOSED,
                    aiohttp.WSMsgType.ERROR,
                ):
                    logger.warning(
                        f"【{self.account_id}】WebSocket连接异常关闭"
                    )
                    self._connected = False
                    break
            else:
                # async for 正常结束（服务端优雅关闭/网络中断，迭代器自然终止，
                # 不产生 CLOSED/ERROR 帧）时同步连接状态，避免标志位卡在 True
                if self._connected:
                    logger.warning(f"【{self.account_id}】WebSocket连接已关闭")
                    self._connected = False
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"【{self.account_id}】消息接收异常: {e}")
            self._connected = False

    def add_push_callback(self, callback):
        """注册推送消息回调（用于向前端转发实时消息）

        Args:
            callback: 异步回调函数，接收解析后的推送消息 dict
        """
        if callback not in self._push_callbacks:
            self._push_callbacks.append(callback)

    def remove_push_callback(self, callback):
        """注销推送消息回调"""
        if callback in self._push_callbacks:
            self._push_callbacks.remove(callback)

    async def _handle_message(self, data: str):
        """处理收到的WebSocket消息"""
        try:
            message = json.loads(data)
        except json.JSONDecodeError:
            return

        # 发送ACK
        headers = message.get("headers", {})
        mid = headers.get("mid", generate_mid())
        ack = {
            "code": 200,
            "headers": {
                "mid": mid,
                "sid": headers.get("sid", ""),
            },
        }
        # 复制需要回传的header字段
        for key in ("app-key", "ua", "dt"):
            if key in headers:
                ack["headers"][key] = headers[key]

        try:
            await self._send_raw(ack)
        except Exception:
            pass

        # 匹配等待中的请求
        # 注意：IM数据响应通常没有code字段，匹配到mid就直接resolve
        if mid in self._pending:
            future = self._pending[mid]
            if not future.done():
                code = message.get("code", 200)
                body = message.get("body", {})
                # 记录错误响应的完整内容
                if isinstance(body, dict) and "reason" in body:
                    logger.warning(
                        f"【{self.account_id}】IM请求响应含错误, "
                        f"code={code}, body={json.dumps(body, ensure_ascii=False)[:300]}"
                    )
                if code == 200 or "body" in message:
                    future.set_result(message)
                else:
                    future.set_exception(
                        ImRequestRejected(
                            f"请求失败: code={code}, "
                            f"msg={json.dumps(message, ensure_ascii=False)[:200]}",
                            code,
                        )
                    )
            return

        # 非请求响应 —— 服务器主动推送的消息，解密并记录日志
        await self._handle_push_message(message)

    async def _handle_push_message(self, message: dict):
        """
        处理服务器主动推送的消息

        参照自动回复 message_handler.py 的解密和解析逻辑：
        1. 检查是否为 syncPushPackage（同步推送包）
        2. 解密每条消息（base64 -> JSON 或 decrypt）
        3. 解析聊天消息内容并打印完整日志
        4. 触发已注册的回调，将解析后的消息推送给前端
        """
        try:
            body = message.get("body", {})
            sync_pkg = body.get("syncPushPackage") if isinstance(body, dict) else None
            if not sync_pkg:
                return
            data_list = sync_pkg.get("data", [])
            if not data_list:
                return

            # 延迟初始化解析器
            if not hasattr(self, "_push_parser"):
                from .push_message_parser import PushMessageParser
                self._push_parser = PushMessageParser(self.account_id, self.myid)

            for sync_data in data_list:
                if not isinstance(sync_data, dict) or "data" not in sync_data:
                    continue
                decrypted = self._push_parser.decrypt_push_data(sync_data["data"])
                if decrypted is None:
                    continue
                parsed = self._push_parser.parse(decrypted)
                if parsed is None:
                    continue
                for cb in self._push_callbacks:
                    try:
                        await cb(parsed)
                    except Exception as cb_e:
                        logger.warning(f"【{self.account_id}】推送回调异常: {cb_e}")
        except Exception as e:
            logger.warning(f"【{self.account_id}】处理推送消息异常: {e}")

    async def _heartbeat_loop(self):
        """心跳保活循环"""
        try:
            while self._connected:
                await asyncio.sleep(HEARTBEAT_INTERVAL)
                if not self._connected or not self._ws or self._ws.closed:
                    break
                try:
                    heartbeat = {
                        "lwp": "/!",
                        "headers": {"mid": generate_mid()},
                    }
                    await self._send_raw(heartbeat)
                except Exception as e:
                    logger.warning(
                        f"【{self.account_id}】心跳发送失败: {e}"
                    )
                    break
        except asyncio.CancelledError:
            pass
