"""
商品链接拷贝到素材库

功能：
1. 从用户粘贴的闲鱼商品链接中解析商品 ID（支持网页链接、App 分享链接、m.tb.cn 短链接）
2. 轮换当前用户的闲鱼账号调用商品详情接口，抓取标题、描述、价格、图片
3. 把图片下载到本地 /static/uploads/products，生成可直接发布的素材

说明：
- 图片下载失败时退回原始远程 URL，保证素材至少可预览
- 解析不到价格时按 1.0 落库，并在返回结果里标记 price_found=false，提示用户手动修改
"""
from __future__ import annotations

import html
import re
from typing import Any, Iterable
from urllib.parse import parse_qs, urlparse

import httpx
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.paths import get_upload_path
from app.services.account_service import AccountService
from app.services.product_publish_service import ProductMaterialService
from common.models.user import User
from common.services.xianyu_detail_client import XianyuItemDetailClient
from common.utils.local_image_upload import ImageUploadError, save_image_bytes

MAX_IMAGES = 9
IMAGE_MAX_BYTES = 5 * 1024 * 1024
DESCRIPTION_MAX_LENGTH = 5000

# 匿名解析：闲鱼网页详情接口允许不带登录态访问，首次请求会下发 _m_h5_tk 令牌。
# mtop 客户端要求 Cookie 字符串非空，这里给一个占位值。
ANONYMOUS_ACCOUNT_ID = "__anonymous__"
ANONYMOUS_COOKIE = "x=1"
ANONYMOUS_LABEL = "匿名（未使用账号）"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)

_URL_RE = re.compile(r"https?://[^\s一-鿿\"'<>]+")

_TITLE_KEYS = ["title", "itemTitle", "item_title", "itemName", "item_name", "subject", "name"]
_DESC_KEYS = [
    "desc", "description", "itemDesc", "item_desc", "detailDesc", "detail_desc",
    "itemDescription", "item_description", "content",
]
_PRICE_KEYS = [
    "price", "currentPrice", "current_price", "soldPrice", "sold_price",
    "reservePrice", "reserve_price", "sellPrice", "sell_price", "priceText", "price_text",
]
_IMAGE_KEYS = (
    "images", "imageInfos", "image_info", "imageList", "image_list",
    "picList", "pic_list", "itemImages", "item_images", "detailImages",
    "detail_images", "imageUrls", "image_urls",
)


class MaterialCopyError(ValueError):
    """拷贝商品失败，消息可直接展示给用户。"""


_ERROR_HINTS = {
    "FAIL_SYS_USER_VALIDATE": "闲鱼账号触发了滑块验证，请到「账号管理」重新登录该账号后再试",
    "FAIL_SYS_SESSION_EXPIRED": "闲鱼账号登录已失效，请到「账号管理」重新登录",
    "FAIL_SYS_ILLEGAL_ACCESS": "闲鱼账号状态异常，请到「账号管理」重新登录",
    "FAIL_SYS_TOKEN_EXOIRED": "闲鱼账号令牌已过期，请到「账号管理」重新登录",
    "FAIL_BIZ_ITEM_NOT_FOUND": "商品不存在或已下架",
    "FAIL_BIZ_ITEM_DEL_NOT_FOUND": "商品不存在或已下架",
}


def _friendly_error(raw: str | None) -> str:
    text = (raw or "").strip()
    if not text:
        return "商品解析失败，请稍后重试"
    for code, hint in _ERROR_HINTS.items():
        if code in text:
            return hint
    # 平台错误码原样保留，方便排查
    return text


def _extract_url(text: str) -> str | None:
    match = _URL_RE.search(text or "")
    return match.group(0).rstrip(".,);]") if match else None


def _item_id_from_url(url: str) -> str | None:
    try:
        parsed = urlparse(url)
    except ValueError:
        return None
    query = parse_qs(parsed.query or "")
    for key in ("id", "itemId", "item_id", "itemid"):
        values = query.get(key)
        if values and values[0].isdigit():
            return values[0]
    match = re.search(r"/item/(\d{6,})", parsed.path or "")
    if match:
        return match.group(1)
    return None


async def resolve_item_id(text: str) -> str:
    """从链接或分享文案中解析闲鱼商品 ID。"""
    raw = (text or "").strip()
    if not raw:
        raise MaterialCopyError("请粘贴闲鱼商品链接")

    if re.fullmatch(r"\d{6,}", raw):
        return raw

    url = _extract_url(raw)
    if not url:
        raise MaterialCopyError("没有找到链接，请粘贴完整的闲鱼商品链接")

    item_id = _item_id_from_url(url)
    if item_id:
        return item_id

    # m.tb.cn / tb.cn 短链接需要跟随跳转
    if "tb.cn" in url:
        try:
            async with httpx.AsyncClient(
                follow_redirects=True,
                timeout=15,
                headers={"User-Agent": USER_AGENT},
            ) as client:
                resp = await client.get(url)
                item_id = _item_id_from_url(str(resp.url)) or _item_id_from_url(resp.text)
                if not item_id:
                    text_match = re.search(r"[?&]id=(\d{6,})", resp.text or "")
                    item_id = text_match.group(1) if text_match else None
                if item_id:
                    return item_id
        except httpx.HTTPError as exc:
            logger.warning(f"短链接解析失败: {url}, error={exc}")

    raise MaterialCopyError("无法从链接中识别商品ID，请使用浏览器里打开商品后复制的链接")


def _iter_nodes(data: Any, limit: int = 3000) -> Iterable[Any]:
    """广度优先遍历嵌套结构。"""
    queue: list[Any] = [data]
    visited = 0
    while queue and visited < limit:
        node = queue.pop(0)
        visited += 1
        yield node
        if isinstance(node, dict):
            queue.extend(value for value in node.values() if isinstance(value, (dict, list)))
        elif isinstance(node, list):
            queue.extend(item for item in node if isinstance(item, (dict, list)))


def _find_first(data: Any, keys: set[str]) -> Any:
    """在嵌套结构里找第一个命中字段名的非空值。"""
    for node in _iter_nodes(data):
        if not isinstance(node, dict):
            continue
        for key, value in node.items():
            if key in keys and value not in (None, "", [], {}):
                return value
    return None


def _find_first_ordered(data: Any, keys: list[str]) -> Any:
    """按字段优先级查找，避免同名字段（如 name）误命中。"""
    for key in keys:
        value = _find_first(data, {key})
        if value not in (None, "", [], {}):
            return value
    return None


def _image_urls_from_node(node: Any) -> list[str]:
    urls: list[str] = []
    if isinstance(node, str):
        urls.append(node)
    elif isinstance(node, dict):
        for key in ("url", "picUrl", "pic_url", "imageUrl", "image_url", "big", "large", "src"):
            value = node.get(key)
            if isinstance(value, str) and value.strip():
                urls.append(value.strip())
                break
    elif isinstance(node, list):
        for item in node:
            urls.extend(_image_urls_from_node(item))
    return urls


def _normalize_image_url(url: str) -> str | None:
    value = (url or "").strip()
    if not value:
        return None
    if value.startswith("//"):
        value = "https:" + value
    if value.startswith("http://"):
        value = "https://" + value[len("http://"):]
    if not value.startswith("https://"):
        return None
    # 过滤头像、图标等非商品图
    if any(keyword in value for keyword in ("avatar", "icon", "logo")):
        return None
    return value


def _extract_images(data: Any) -> list[str]:
    candidates: list[str] = []
    for key in _IMAGE_KEYS:
        node = _find_first(data, {key})
        if node is None:
            continue
        candidates = _image_urls_from_node(node)
        normalized = [url for url in (_normalize_image_url(item) for item in candidates) if url]
        if normalized:
            return _dedupe(normalized)[:MAX_IMAGES]
    return []


def _dedupe(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def _clean_description(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    text = re.sub(r"<\s*br\s*/?\s*>", "\n", value, flags=re.IGNORECASE)
    text = re.sub(r"</\s*p\s*>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", "", text)
    text = html.unescape(text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()[:DESCRIPTION_MAX_LENGTH]


def _parse_price(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value) if value > 0 else None
    match = re.search(r"\d+(?:\.\d+)?", str(value).replace(",", ""))
    if not match:
        return None
    try:
        parsed = float(match.group(0))
    except ValueError:
        return None
    return parsed if parsed > 0 else None


def extract_detail_fields(detail: Any) -> dict[str, Any]:
    """从详情接口返回的数据中提取标题 / 描述 / 价格 / 图片。"""
    if not isinstance(detail, dict):
        detail = {}
    # 优先看 itemDO，其次整棵结构
    item_node = detail.get("itemDO") if isinstance(detail.get("itemDO"), dict) else detail

    title_value = _find_first_ordered(item_node, _TITLE_KEYS) or _find_first_ordered(detail, _TITLE_KEYS)
    title = str(title_value).strip() if isinstance(title_value, (str, int, float)) else ""

    desc_value = _find_first_ordered(item_node, _DESC_KEYS) or _find_first_ordered(detail, _DESC_KEYS)
    description = _clean_description(desc_value)

    price_value = _find_first_ordered(item_node, _PRICE_KEYS) or _find_first_ordered(detail, _PRICE_KEYS)
    price = _parse_price(price_value)

    images = _extract_images(item_node) or _extract_images(detail)

    return {
        "title": title[:200],
        "description": description,
        "price": price,
        "images": images,
        "raw_keys": list(detail.keys())[:30],
    }


class MaterialCopyService:
    """把闲鱼商品链接拷贝为素材。"""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def copy_from_link(
        self,
        current_user: User,
        url: str,
        account_id: str | None = None,
        *,
        is_admin: bool = False,
    ) -> dict[str, Any]:
        item_id = await resolve_item_id(url)
        accounts = await self._candidate_accounts(current_user.id, account_id, is_admin)
        if account_id and not accounts:
            raise MaterialCopyError("指定的闲鱼账号不存在或没有 Cookie，请重新选择")

        # 未指定账号时匿名优先（不需要登录态、也不会消耗账号风控额度），
        # 匿名解析失败再依次尝试当前用户的账号。
        sources: list[Any] = accounts if account_id else [None, *accounts]

        last_error = "商品解析失败，请稍后重试"
        for index, account in enumerate(sources):
            if account is None:
                client = XianyuItemDetailClient(ANONYMOUS_ACCOUNT_ID, ANONYMOUS_COOKIE)
            else:
                client = XianyuItemDetailClient(
                    account.account_id,
                    account.cookie,
                    owner_id=account.owner_id,
                )
            result = await client.get_detail(item_id)

            # 令牌刷新后回写 Cookie，避免下次还用旧值
            if (
                account is not None
                and client.cookies_str
                and client.cookies_str != account.cookie
            ):
                account.cookie = client.cookies_str
                try:
                    await self.session.commit()
                except Exception as exc:  # 回写失败不影响本次采集
                    await self.session.rollback()
                    logger.warning(f"回写账号 Cookie 失败: {exc}")

            if result.get("success"):
                fields = extract_detail_fields(result.get("detail") or {})
                if not fields["title"]:
                    last_error = "已获取商品详情，但未解析出标题，可能触发了闲鱼验证"
                    logger.warning(f"{last_error}（{ANONYMOUS_LABEL if account is None else account.account_id}）")
                    if index < len(sources) - 1:
                        continue
                    raise MaterialCopyError(last_error)
                return await self._create_material(
                    current_user.id,
                    item_id=item_id,
                    account_label=ANONYMOUS_LABEL if account is None else account.account_id,
                    fields=fields,
                    referer=url,
                )

            raw_error = result.get("error") or ""
            last_error = _friendly_error(raw_error)
            source_label = ANONYMOUS_LABEL if account is None else account.account_id
            logger.warning(f"拷贝商品失败（{source_label}）: {raw_error or last_error}")
            if index < len(sources) - 1:
                logger.info("尝试切换下一个解析来源")

        if not accounts:
            raise MaterialCopyError(
                f"匿名解析失败：{last_error}。可在「账号管理」登录一个闲鱼账号后重试"
            )
        raise MaterialCopyError(last_error)

    async def _candidate_accounts(
        self, user_id: int, account_id: str | None, is_admin: bool
    ) -> list[Any]:
        account_service = AccountService(self.session)
        if account_id:
            scope = None if is_admin else user_id
            account = await account_service.get_account_for_user(scope, account_id)
            return [account] if account and (account.cookie or "").strip() else []

        accounts = await account_service.list_accounts(user_id)
        with_cookie = [account for account in accounts if (account.cookie or "").strip()]
        return sorted(
            with_cookie,
            key=lambda item: (item.status or "").strip().lower() != "active",
        )

    async def _create_material(
        self,
        user_id: int,
        *,
        item_id: str,
        account_label: str,
        fields: dict[str, Any],
        referer: str,
    ) -> dict[str, Any]:
        remote_images = fields["images"]
        local_images = await self._download_images(remote_images, referer=referer)
        images = local_images or remote_images
        price = fields["price"] or 1.0

        payload = {
            "title": fields["title"],
            "description": fields["description"],
            "price": price,
            "original_price": None,
            "category": None,
            "condition": "全新",
            "images": images,
            "videos": [],
            "specifications": [],
            "sku_rows": [],
            "quantity": 1,
            "delivery_method": "express",
            "shipping_method": "free",
            "support_pickup": False,
            "postage": 0,
            "remark": f"拷贝自闲鱼商品 {item_id}",
        }
        material = await ProductMaterialService(self.session).create(user_id, payload)

        logger.info(
            f"拷贝商品成功: item_id={item_id}, material_id={material.id}, "
            f"source={account_label}, images={len(images)} (本地 {len(local_images)})"
        )
        return {
            "material_id": material.id,
            "title": material.title,
            "price": float(material.price),
            "price_found": fields["price"] is not None,
            "image_count": len(images),
            "local_image_count": len(local_images),
            "images": images[:3],
            "account_id": account_label,
            "item_id": item_id,
        }

    async def _download_images(self, urls: list[str], *, referer: str) -> list[str]:
        if not urls:
            return []
        saved: list[str] = []
        upload_dir = get_upload_path("products")
        headers = {
            "User-Agent": USER_AGENT,
            "Referer": referer if referer.startswith("http") else "https://www.goofish.com/",
        }
        async with httpx.AsyncClient(
            follow_redirects=True, timeout=20, headers=headers
        ) as client:
            for url in urls[:MAX_IMAGES]:
                try:
                    response = await client.get(url)
                    if response.status_code != 200 or not response.content:
                        logger.warning(f"商品图片下载失败: {url}, status={response.status_code}")
                        continue
                    _, filename = await save_image_bytes(
                        response.content,
                        upload_dir,
                        filename_prefix="copy",
                        max_size=IMAGE_MAX_BYTES,
                    )
                    saved.append(f"/static/uploads/products/{filename}")
                except ImageUploadError as exc:
                    logger.warning(f"商品图片保存失败: {url}, error={exc}")
                except httpx.HTTPError as exc:
                    logger.warning(f"商品图片下载异常: {url}, error={exc}")
        return saved
