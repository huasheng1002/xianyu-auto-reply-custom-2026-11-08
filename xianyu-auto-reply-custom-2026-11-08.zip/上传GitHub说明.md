# 是否上传 GitHub + 上传前必须标明什么

## 一、需要上传 GitHub 吗？

**不需要。** 部署和分享用 `xianyu-auto-reply-custom-2026-11-08.zip` 就够了，包里有完整源码和一键脚本。

上传 GitHub 只在这几种情况下有价值：

| 目的 | 建议 |
|---|---|
| 自己多台机器同步、保留版本历史 | 建议上传（私有仓库） |
| 分享给朋友/客户 | 可以上传，也可以直接给 zip |
| 接受别人提交改进 | 上传（公开仓库） |
| 只想部署到服务器 | 不用上传 |

## 二、上传前必须标明的内容

### 1. 许可证（硬性）

- 上游是 **AGPL-3.0**，必须保留根目录 `LICENSE`，不能改成 MIT、Apache 或闭源
- 修改版也必须继续使用 AGPL-3.0
- 保留源码文件里原有的版权头

### 2. 来源与修改声明（硬性）

在 README 顶部加一段，或直接引用 `MODIFICATIONS.md`：

```markdown
> 本仓库基于 [zhinianboke/xianyu-auto-reply](https://github.com/zhinianboke/xianyu-auto-reply)（版本 20260919）修改。
> 本仓库为非官方衍生版本，与原作者无关，不代表原作者观点。
> 修改内容与修改日期见 [MODIFICATIONS.md](./MODIFICATIONS.md)。
> 许可证：AGPL-3.0，沿用上游 LICENSE。
```

### 3. 修改日期与内容（硬性）

AGPL 第 5 条要求标明修改。`MODIFICATIONS.md` 已写好（新增功能、修改文件清单、日期），直接一起上传即可。

### 4. 不要上传的内容

`.gitignore` 已覆盖，推送前再确认一遍：

```text
.env                 数据库密码、密钥
xianyu_auto_reply/   MySQL/Redis 数据、日志、备份
backend-web/static/uploads/   用户上传的图片
backups/             数据库备份
node_modules/ .venv/ 依赖
```

> 特别注意：`backend-web/static/uploads/products/` 里有测试时下载的商品图，**不要上传**。

### 5. 网络服务义务（AGPL 第 13 条）

如果你把这个系统部署成网站给用户使用，必须向这些用户提供**完整对应源码**（通常放一个指向本仓库的链接即可）。这也是为什么建议公开仓库或至少让用户能获取源码。

## 三、怎么上传（两种方式）

### 方式 A：网页建空仓库 + 一键推送脚本（推荐）

1. 打开 https://github.com/new 新建仓库（不要勾选 README、.gitignore、License）
2. 把本包解压到一个目录，双击 **`push-to-github.cmd`**
3. 粘贴仓库地址，例如 `https://github.com/你的用户名/xianyu-auto-reply-plus.git`
4. 按提示完成 GitHub 登录授权

脚本等价于：

```bash
git init
git add .
git commit -m "feat: 素材库导入导出、拷贝商品、图片水印（基于上游 20260919）"
git branch -M main
git remote add origin <仓库地址>
git push -u origin main
```

### 方式 B：GitHub 网页「Import repository」

GitHub 的 **Import repository**（https://github.com/new/import）只能从**已有 URL** 导入，不能直接导入本地 zip。

可行做法：

1. 先 Fork 上游：https://github.com/zhinianboke/xianyu-auto-reply/fork
2. 把你的 zip 解压后覆盖到本地 clone 的目录
3. `git add . && git commit && git push`

如果你只是想让别人看到你的修改，**方式 A 更简单**。

### 方式 C：安装 GitHub CLI 后真正一条命令

```bash
winget install GitHub.cli
gh auth login
gh repo create xianyu-auto-reply-plus --public --source=. --push
```

前提是当前目录已经是 git 仓库（先执行方式 A 的前三条 git 命令）。

## 四、复制一份声明到 README

如果不想改动原 README 太多，只需在文件最顶部插入这一行：

```markdown
> 本仓库为衍生修改版，基于 https://github.com/zhinianboke/xianyu-auto-reply（20260919），修改说明见 MODIFICATIONS.md，许可证 AGPL-3.0。
```
