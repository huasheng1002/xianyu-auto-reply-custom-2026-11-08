"""
商品素材库导入 / 导出服务

功能：
1. 导出素材为 Excel（.xlsx），嵌套字段（图片、视频、规格、SKU、平台分类）以 JSON 文本保存
2. 从同格式 Excel 导入素材，逐行校验，单行失败不影响其他行
3. 导入只新增素材，不会覆盖或删除已有素材

点：一行素材的完整字段都在一张表里，导出后可以直接改完再导回。
"""
from __future__ import annotations

import io
import json
from typing import Any, Iterable

from loguru import logger
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from common.models.product_material import ProductMaterial
from common.models.user import User
from app.services.product_publish_service import ProductMaterialService, _material_to_dict

MAX_IMPORT_ROWS = 1000
MAX_IMPORT_BYTES = 10 * 1024 * 1024
MAX_IMAGES = 9

# (Excel 表头, 素材字段)
COLUMNS: list[tuple[str, str]] = [
    ("标题", "title"),
    ("描述", "description"),
    ("价格", "price"),
    ("原价", "original_price"),
    ("本地分类", "category"),
    ("平台分类ID", "platform_category_id"),
    ("平台分类名称", "platform_category_name"),
    ("平台频道分类ID", "platform_channel_category_id"),
    ("平台频道分类名称", "platform_channel_category_name"),
    ("平台叶子ID", "platform_leaf_id"),
    ("淘宝分类ID", "platform_tb_category_id"),
    ("平台分类路径(JSON)", "platform_category_path"),
    ("平台属性(JSON)", "platform_attributes"),
    ("分类来源", "category_source"),
    ("图片URL(JSON数组)", "images"),
    ("视频(JSON数组)", "videos"),
    ("规格(JSON)", "specifications"),
    ("SKU组合(JSON)", "sku_rows"),
    ("数量", "quantity"),
    ("发货方式", "delivery_method"),
    ("运费方式", "shipping_method"),
    ("支持自提", "support_pickup"),
    ("邮费", "postage"),
    ("所在地", "address"),
    ("所在地期望文本", "address_expected_text"),
    ("品牌", "brand"),
    ("成色", "condition"),
    ("备注", "remark"),
]

JSON_FIELDS = {
    "platform_category_path",
    "platform_attributes",
    "images",
    "videos",
    "specifications",
    "sku_rows",
}
BOOL_FIELDS = {"support_pickup"}
NUMBER_FIELDS = {"price", "original_price", "postage", "quantity"}
SHIPPING_METHODS = {"free", "distance", "fixed", "template", "none"}
CONDITIONS = {"全新", "99新", "95新", "9成新", "8成新", "7成新以下"}

# 表头 -> 字段 的查找表，同时兼容英文字段名，方便用户自行生成表格
HEADER_TO_FIELD = {header: field for header, field in COLUMNS}
HEADER_TO_FIELD.update({field: field for _, field in COLUMNS})
HEADER_TO_FIELD["所属用户"] = "__username__"


def _cell_value(value: Any) -> str:
    """把值写成 Excel 单元格文本，避免 Excel 自动转换类型。"""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "是" if value else "否"
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, float) and value == int(value):
        return str(int(value))
    return str(value)


def _write_sheet(wb: Workbook, title: str, headers: list[str], rows: list[list[Any]]) -> None:
    ws = wb.create_sheet(title=title)
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = Font(bold=True)
    for row_idx, row_data in enumerate(rows, 2):
        for col_idx, value in enumerate(row_data, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=_cell_value(value))
            cell.number_format = "@"
    for col_idx, header in enumerate(headers, 1):
        letter = get_column_letter(col_idx)
        width = len(str(header)) + 2
        for row_idx in range(2, min(len(rows) + 2, 200)):
            width = max(width, min(len(str(ws.cell(row=row_idx, column=col_idx).value or "")), 60) + 2)
        ws.column_dimensions[letter].width = width
    ws.freeze_panes = "A2"


class MaterialTransferService:
    """素材库导入导出服务。"""

    def __init__(self, session: AsyncSession):
        self.session = session

    # ---------------- 导出 ----------------

    async def export_materials(
        self,
        owner_id: int | None,
        material_ids: list[int] | None = None,
        filters: dict | None = None,
        include_username: bool = False,
    ) -> io.BytesIO:
        """导出素材为 Excel。

        Args:
            owner_id: None 表示管理员导出全部用户，否则只导出该用户
            material_ids: 勾选导出，优先级高于筛选条件
            filters: title / category / condition / platform_category_id
            include_username: 管理员导出时附带所属用户列（导入时忽略）
        """
        cond = [ProductMaterial.is_deleted.is_(False)]
        if owner_id is not None:
            cond.append(ProductMaterial.user_id == owner_id)

        if material_ids:
            cond.append(ProductMaterial.id.in_(material_ids))
        elif filters:
            title = (filters.get("title") or "").strip()
            category = (filters.get("category") or "").strip()
            condition = (filters.get("condition") or "").strip()
            platform_category_id = (filters.get("platform_category_id") or "").strip()
            if title:
                cond.append(ProductMaterial.title.ilike(f"%{title}%"))
            if category:
                cond.append(ProductMaterial.category == category)
            if condition:
                cond.append(ProductMaterial.condition == condition)
            if platform_category_id:
                cond.append(ProductMaterial.platform_category_id == platform_category_id)

        stmt = select(ProductMaterial).where(*cond).order_by(desc(ProductMaterial.created_at))
        materials = (await self.session.execute(stmt)).scalars().all()

        username_map: dict[int, str] = {}
        if include_username and materials:
            user_ids = {m.user_id for m in materials}
            rows = (await self.session.execute(
                select(User.id, User.username).where(User.id.in_(user_ids))
            )).all()
            username_map = {r.id: r.username for r in rows}

        headers = [header for header, _ in COLUMNS]
        if include_username:
            headers = ["所属用户（导入时忽略）"] + headers

        rows: list[list[Any]] = []
        for material in materials:
            data = _material_to_dict(material)
            row = [data.get(field) for _, field in COLUMNS]
            if include_username:
                row = [username_map.get(material.user_id, str(material.user_id))] + row
            rows.append(row)

        wb = Workbook()
        wb.remove(wb.active)
        _write_sheet(wb, "素材库", headers, rows)
        if not rows:
            # 空数据也保留表头，方便用户按模板填写后导入
            logger.info("素材库导出：没有符合条件的数据，仅导出表头")

        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        return output

    # ---------------- 导入 ----------------

    async def import_materials(self, user_id: int, content: bytes) -> dict[str, Any]:
        """从 Excel 导入素材，逐行创建，返回成功/失败统计。"""
        if len(content) > MAX_IMPORT_BYTES:
            raise ValueError("文件超过 10MB，请拆分后导入")
        if not content:
            raise ValueError("文件内容为空")

        try:
            wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
        except Exception as exc:
            raise ValueError(f"无法解析 Excel 文件：{exc}") from exc

        ws = wb.worksheets[0]
        rows = ws.iter_rows(values_only=True)
        try:
            header_row = next(rows)
        except StopIteration:
            raise ValueError("表格为空")

        field_index: dict[int, str] = {}
        for idx, header in enumerate(header_row):
            if header is None:
                continue
            name = str(header).strip()
            if name.endswith("（导入时忽略）"):
                continue
            field = HEADER_TO_FIELD.get(name)
            if field:
                field_index[idx] = field

        if "title" not in field_index.values() or "price" not in field_index.values():
            raise ValueError("表头缺少「标题」或「价格」列，请使用导出的文件作为模板")

        service = ProductMaterialService(self.session)
        inserted = 0
        failed = 0
        errors: list[str] = []
        data_rows = 0
        limit_reached = False

        for row_number, raw_row in enumerate(rows, start=2):
            if raw_row is None:
                continue
            if all(cell is None or str(cell).strip() == "" for cell in raw_row):
                continue
            if data_rows >= MAX_IMPORT_ROWS:
                limit_reached = True
                break
            data_rows += 1

            try:
                payload = self._build_payload(field_index, raw_row)
            except ValueError as exc:
                failed += 1
                errors.append(f"第 {row_number} 行：{exc}")
                continue

            try:
                await service.create(user_id, payload)
            except Exception as exc:  # 单行失败不影响后续行
                # 某一行写库失败后会话处于失效状态，必须回滚，否则后续行全部报
                # PendingRollbackError
                await self.session.rollback()
                logger.warning(f"素材导入第 {row_number} 行失败: {exc}")
                failed += 1
                errors.append(f"第 {row_number} 行：{exc}")
                continue
            inserted += 1

        wb.close()
        result: dict[str, Any] = {
            "inserted": inserted,
            "failed": failed,
            "total": data_rows,
            "errors": errors[:50],
        }
        if limit_reached:
            result["limit_reached"] = True
            result["message"] = f"单次最多导入 {MAX_IMPORT_ROWS} 行，超出部分未处理"
        return result

    def _build_payload(self, field_index: dict[int, str], raw_row: Iterable[Any]) -> dict[str, Any]:
        raw: dict[str, Any] = {}
        for idx, field in field_index.items():
            value = raw_row[idx] if idx < len(raw_row) else None
            raw[field] = value

        title = self._as_text(raw.get("title"))
        if not title:
            raise ValueError("标题不能为空")
        if len(title) > 200:
            raise ValueError("标题超过 200 字")

        price = self._as_float(raw.get("price"))
        if price is None or price <= 0:
            raise ValueError("价格必须是大于 0 的数字")

        payload: dict[str, Any] = {
            "title": title,
            "description": self._as_text(raw.get("description")),
            "price": price,
            "original_price": self._as_float(raw.get("original_price")),
            "category": self._as_text(raw.get("category")) or None,
            "platform_category_id": self._as_text(raw.get("platform_category_id")) or None,
            "platform_category_name": self._as_text(raw.get("platform_category_name")) or None,
            "platform_channel_category_id": self._as_text(raw.get("platform_channel_category_id")) or None,
            "platform_channel_category_name": self._as_text(raw.get("platform_channel_category_name")) or None,
            "platform_leaf_id": self._as_text(raw.get("platform_leaf_id")) or None,
            "platform_tb_category_id": self._as_text(raw.get("platform_tb_category_id")) or None,
            "platform_category_path": self._as_json(raw.get("platform_category_path"), "平台分类路径", []),
            "platform_attributes": self._as_json(raw.get("platform_attributes"), "平台属性", []),
            "category_source": self._as_text(raw.get("category_source")) or "manual",
            "images": self._as_json(raw.get("images"), "图片URL", []),
            "videos": self._as_json(raw.get("videos"), "视频", []),
            "specifications": self._as_json(raw.get("specifications"), "规格", []),
            "sku_rows": self._as_json(raw.get("sku_rows"), "SKU组合", []),
            "quantity": self._as_int(raw.get("quantity"), 1),
            "postage": self._as_float(raw.get("postage")) or 0,
            "address": self._as_text(raw.get("address")) or None,
            "address_expected_text": self._as_text(raw.get("address_expected_text")) or None,
            "brand": self._as_text(raw.get("brand")) or None,
            "condition": self._as_text(raw.get("condition")) or "全新",
            "remark": self._as_text(raw.get("remark")) or None,
            "support_pickup": self._as_bool(raw.get("support_pickup")),
        }

        shipping_method = self._as_text(raw.get("shipping_method")) or "free"
        if shipping_method not in SHIPPING_METHODS:
            shipping_method = "free"
        payload["shipping_method"] = shipping_method
        payload["delivery_method"] = "pickup" if shipping_method == "none" else "express"

        images = payload["images"]
        if isinstance(images, list):
            payload["images"] = [str(item) for item in images if item][:MAX_IMAGES]
        else:
            payload["images"] = []

        if payload["condition"] not in CONDITIONS:
            payload["condition"] = "全新"

        return payload

    @staticmethod
    def _as_text(value: Any) -> str:
        if value is None:
            return ""
        return str(value).strip()

    @staticmethod
    def _as_float(value: Any) -> float | None:
        if value is None or (isinstance(value, str) and not value.strip()):
            return None
        try:
            return float(str(value).replace(",", "").strip())
        except (TypeError, ValueError):
            raise ValueError(f"「{value}」不是有效数字")

    @staticmethod
    def _as_int(value: Any, default: int) -> int:
        if value is None or (isinstance(value, str) and not value.strip()):
            return default
        try:
            parsed = int(float(str(value).strip()))
        except (TypeError, ValueError):
            return default
        return parsed if parsed >= 1 else default

    @staticmethod
    def _as_bool(value: Any) -> bool:
        if isinstance(value, bool):
            return value
        text = str(value or "").strip().lower()
        return text in {"是", "true", "1", "yes", "y"}

    @staticmethod
    def _as_json(value: Any, label: str, default: Any) -> Any:
        if value is None or (isinstance(value, str) and not value.strip()):
            return default
        if isinstance(value, (list, dict)):
            return value
        try:
            parsed = json.loads(str(value))
        except (TypeError, ValueError):
            raise ValueError(f"{label}不是合法 JSON")
        expected_type = type(default)
        if expected_type is list and not isinstance(parsed, list):
            raise ValueError(f"{label}必须是 JSON 数组")
        if expected_type is dict and not isinstance(parsed, dict):
            raise ValueError(f"{label}必须是 JSON 对象")
        return parsed
