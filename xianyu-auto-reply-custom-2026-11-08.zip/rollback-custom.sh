#!/usr/bin/env bash
# ==========================================
# 闲鱼自动回复系统 - 回滚到上一次镜像
#
# 前提：install-custom.sh 构建前会给旧镜像打 :prev 标签
# 用法：bash rollback-custom.sh
# ==========================================

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'; NC='\033[0m'

WORK_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$WORK_DIR"

COMPOSE_FILE="$WORK_DIR/docker-compose.custom.yml"
ENV_FILE="$WORK_DIR/.env"
export COMPOSE_PROJECT_NAME="xianyu-auto-reply"
APP_IMAGES=(xianyu-custom-backend-web xianyu-custom-websocket xianyu-custom-scheduler xianyu-custom-frontend)

if docker compose version >/dev/null 2>&1; then
    DC=(docker compose)
else
    DC=(docker-compose)
fi
DC_CMD=("${DC[@]}" -f "$COMPOSE_FILE")
[ -f "$ENV_FILE" ] && DC_CMD+=("--env-file" "$ENV_FILE")

echo "=========================================="
echo "  回滚到上一次镜像"
echo "=========================================="

MISSING=0
for image in "${APP_IMAGES[@]}"; do
    if docker image inspect "${image}:prev" >/dev/null 2>&1; then
        docker tag "${image}:prev" "${image}:latest"
        echo -e "${GREEN}  ✓ ${image}:prev -> latest${NC}"
    else
        echo -e "${YELLOW}  ! 未找到 ${image}:prev${NC}"
        MISSING=1
    fi
done

if [ "$MISSING" -eq 1 ]; then
    echo ""
    echo -e "${RED}缺少回滚镜像，无法自动回滚。${NC}"
    echo "请改用上一版源码包重新执行：bash install-custom.sh"
    exit 1
fi

echo ""
echo -e "${YELLOW}重新启动服务...${NC}"
"${DC_CMD[@]}" up -d --no-build
echo ""
"${DC_CMD[@]}" ps
echo ""
echo -e "${GREEN}回滚完成。${NC}"
