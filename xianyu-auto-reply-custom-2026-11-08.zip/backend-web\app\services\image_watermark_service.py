"""
素材图片水印服务

功能：
1. 两种水印模式：tile（整张图片平铺） / single（单条水印）
2. 水印内容、字号、颜色、透明度、旋转角度、位置来自系统设置（watermark.*）
3. 处理本地静态图片（/static/...），生成新文件并回写素材的 images 字段
4. 去水印：预留 AI 接口钩子，未配置时返回明确的"未开放"提示

注意：
- 只处理本地 /static/ 下的图片，远程 URL 会跳过并计入 skipped
- 原图保留，新图以 wm_ 前缀落盘，避免误删原素材
"""
from __future__ import annotations

import io
import re
import uuid
from pathlib import Path
from typing import Any

from loguru import logger
from PIL import Image, ImageDraw, ImageFont, ImageOps
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.paths import STATIC_ROOT
from common.models.product_material import ProductMaterial
from common.models.user import User
from app.services.system_setting_service import SystemSettingService

MAX_MATERIALS_PER_REQUEST = 50
MAX_IMAGE_BYTES = 20 * 1024 * 1024
JPEG_QUALITY = 92

WATERMARK_DEFAULTS: dict[str, str] = {
    "watermark.content": "闲鱼素材",
    "watermark.font_size": "42",
    "watermark.color": "#FFFFFF",
    "watermark.opacity": "0.35",
    "watermark.rotation": "30",
    "watermark.position": "center",
    "watermark.ai_remove_url": "",
    "watermark.ai_remove_key": "",
}

POSITION_LABELS = {
    "center": "居中",
    "top_left": "左上角",
    "top_right": "右上角",
    "bottom_left": "左下角",
    "bottom_right": "右下角",
}

# 按优先级查找可用字体（Windows 本地 / Debian 容器）
FONT_CANDIDATES = [
    "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/simhei.ttf",
    "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]


class WatermarkError(ValueError):
    """水印处理失败，消息可直接展示给用户。"""


def _load_font(size: int) -> ImageFont.ImageFont:
    safe_size = max(8, min(int(size), 400))
    for path in FONT_CANDIDATES:
        if Path(path).exists():
            try:
                return ImageFont.truetype(path, safe_size)
            except Exception:  # noqa: BLE001
                continue
    logger.warning("未找到可用中文字体，水印将使用 Pillow 默认字体（不支持中文）")
    return ImageFont.load_default()


def _parse_color(value: str) -> tuple[int, int, int]:
    text = (value or "").strip()
    if re.fullmatch(r"#?[0-9a-fA-F]{6}", text):
        text = text.lstrip("#")
        return int(text[0:2], 16), int(text[2:4], 16), int(text[4:6], 16)
    if re.fullmatch(r"#?[0-9a-fA-F]{3}", text):
        text = text.lstrip("#")
        return tuple(int(ch * 2, 16) for ch in text)  # type: ignore[return-value]
    return 255, 255, 255


def _parse_float(value: Any, default: float, minimum: float, maximum: float) -> float:
    try:
        parsed = float(str(value).strip())
    except (TypeError, ValueError):
        return default
    return max(minimum, min(parsed, maximum))


def normalize_watermark_settings(raw: dict[str, str]) -> dict[str, Any]:
    """把数据库里的字符串配置转成可用的水印参数。"""
    merged = {**WATERMARK_DEFAULTS, **(raw or {})}
    content = str(merged.get("watermark.content") or "").strip() or WATERMARK_DEFAULTS["watermark.content"]
    position = str(merged.get("watermark.position") or "center").strip()
    if position not in POSITION_LABELS:
        position = "center"
    return {
        "content": content,
        "font_size": _parse_float(merged.get("watermark.font_size"), 42, 8, 400),
        "color": _parse_color(str(merged.get("watermark.color") or "#FFFFFF")),
        "opacity": _parse_float(merged.get("watermark.opacity"), 0.35, 0.02, 1.0),
        "rotation": _parse_float(merged.get("watermark.rotation"), 30, -180, 180),
        "position": position,
        "ai_remove_url": str(merged.get("watermark.ai_remove_url") or "").strip(),
        "ai_remove_key": str(merged.get("watermark.ai_remove_key") or "").strip(),
    }


def _build_text_layer(settings: dict[str, Any]) -> Image.Image:
    text = str(settings["content"]).replace("\n", " ")
    font = _load_font(int(settings["font_size"]))
    r, g, b = settings["color"]
    alpha = int(round(255 * float(settings["opacity"])))

    pad = max(6, int(settings["font_size"] * 0.2))
    bbox = ImageDraw.Draw(Image.new("RGBA", (1, 1))).textbbox((0, 0), text, font=font)
    width = max(1, bbox[2] - bbox[0] + pad * 2)
    height = max(1, bbox[3] - bbox[1] + pad * 2)

    layer = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    # 描边：白色水印落在白底图片上时仍然可见
    stroke_width = max(1, int(settings["font_size"] // 22))
    stroke_alpha = max(20, int(alpha * 0.45))
    draw.text(
        (pad - bbox[0], pad - bbox[1]),
        text,
        font=font,
        fill=(r, g, b, alpha),
        stroke_width=stroke_width,
        stroke_fill=(0, 0, 0, stroke_alpha),
    )

    rotation = float(settings["rotation"])
    if rotation:
        layer = layer.rotate(rotation, expand=True, resample=Image.BICUBIC)
    return layer


def _apply_tile(base: Image.Image, layer: Image.Image, gap: int) -> Image.Image:
    width, height = base.size
    layer_w, layer_h = layer.size
    if layer_w <= 0 or layer_h <= 0:
        return base

    step_x = layer_w + gap
    step_y = layer_h + gap
    overlay = Image.new("RGBA", base.size, (0, 0, 0, 0))

    row = 0
    y = -layer_h
    while y < height + layer_h:
        offset = (step_x // 2) if row % 2 else 0
        x = -layer_w - offset
        while x < width + layer_w:
            # paste 支持负坐标，会自动裁掉越界部分
            overlay.paste(layer, (int(x), int(y)), layer)
            x += step_x
        y += step_y
        row += 1

    return Image.alpha_composite(base.convert("RGBA"), overlay)


def _apply_single(base: Image.Image, layer: Image.Image, position: str, gap: int) -> Image.Image:
    width, height = base.size
    layer_w, layer_h = layer.size
    margin = max(16, gap)
    positions = {
        "center": ((width - layer_w) // 2, (height - layer_h) // 2),
        "top_left": (margin, margin),
        "top_right": (width - layer_w - margin, margin),
        "bottom_left": (margin, height - layer_h - margin),
        "bottom_right": (width - layer_w - margin, height - layer_h - margin),
    }
    x, y = positions.get(position, positions["center"])
    overlay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    overlay.paste(layer, (int(x), int(y)), layer)
    return Image.alpha_composite(base.convert("RGBA"), overlay)


def watermark_image(content: bytes, mode: str, settings: dict[str, Any]) -> tuple[bytes, str]:
    """给单张图片加水印，返回 (图片字节, 扩展名)。"""
    if not content:
        raise WatermarkError("图片内容为空")
    if len(content) > MAX_IMAGE_BYTES:
        raise WatermarkError("图片超过 20MB，已跳过")

    try:
        image = Image.open(io.BytesIO(content))
        image.load()
    except Exception as exc:  # noqa: BLE001
        raise WatermarkError(f"无法读取图片：{exc}") from exc

    image = ImageOps.exif_transpose(image)
    original_format = (image.format or "").upper()
    ext = ".png" if original_format == "PNG" else ".jpg"

    layer = _build_text_layer(settings)
    gap = max(24, int(settings["font_size"]))
    if mode == "single":
        result_image = _apply_single(image, layer, settings["position"], gap)
    else:
        result_image = _apply_tile(image, layer, gap)

    output = io.BytesIO()
    if ext == ".png":
        result_image.save(output, format="PNG", optimize=True)
    else:
        result_image.convert("RGB").save(
            output, format="JPEG", quality=JPEG_QUALITY, optimize=True
        )
    return output.getvalue(), ext


def url_to_local_path(url: str) -> Path | None:
    """把 /static/... URL 映射为本地文件路径，非法路径返回 None。"""
    text = (url or "").strip()
    if not text.startswith("/static/"):
        return None
    relative = text[len("/static/"):].split("?", 1)[0]
    target = (STATIC_ROOT / relative).resolve()
    try:
        target.relative_to(STATIC_ROOT.resolve())
    except ValueError:
        return None
    return target if target.is_file() else None


class ImageWatermarkService:
    """素材图片水印服务。"""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def load_settings(self) -> dict[str, Any]:
        raw = await SystemSettingService(self.session).list_settings()
        return normalize_watermark_settings(raw)

    async def _load_materials(
        self, ids: list[int], user_id: int, is_admin: bool
    ) -> list[ProductMaterial]:
        unique_ids = list(dict.fromkeys(int(i) for i in ids))[:MAX_MATERIALS_PER_REQUEST]
        cond = [
            ProductMaterial.id.in_(unique_ids),
            ProductMaterial.is_deleted.is_(False),
        ]
        if not is_admin:
            cond.append(ProductMaterial.user_id == user_id)
        stmt = select(ProductMaterial).where(*cond)
        rows = (await self.session.execute(stmt)).scalars().all()
        order = {mid: index for index, mid in enumerate(unique_ids)}
        return sorted(rows, key=lambda item: order.get(item.id, 0))

    async def apply_watermark(
        self,
        current_user: User,
        ids: list[int],
        mode: str,
        *,
        is_admin: bool = False,
    ) -> dict[str, Any]:
        if mode not in {"tile", "single"}:
            raise WatermarkError("水印模式无效")
        if not ids:
            raise WatermarkError("请先选择素材")
        if len(ids) > MAX_MATERIALS_PER_REQUEST:
            raise WatermarkError(f"单次最多处理 {MAX_MATERIALS_PER_REQUEST} 条素材，请分批操作")

        settings = await self.load_settings()
        materials = await self._load_materials(ids, current_user.id, is_admin)
        if not materials:
            raise WatermarkError("没有找到可处理的素材")

        processed_images = 0
        skipped_images = 0
        failed = 0
        errors: list[str] = []
        touched = 0

        for material in materials:
            images = list(material.images or [])
            new_images: list[str] = []
            changed = False
            for url in images:
                path = url_to_local_path(url)
                if path is None:
                    skipped_images += 1
                    new_images.append(url)
                    continue
                try:
                    content = path.read_bytes()
                    watermarked, ext = watermark_image(content, mode, settings)
                    filename = f"wm_{uuid.uuid4().hex}{ext}"
                    target = path.parent / filename
                    target.write_bytes(watermarked)
                    new_images.append(f"/static/uploads/{path.parent.relative_to(STATIC_ROOT / 'uploads').as_posix()}/{filename}")
                    processed_images += 1
                    changed = True
                except Exception as exc:  # noqa: BLE001
                    failed += 1
                    logger.warning(f"素材 {material.id} 图片加水印失败: {exc}")
                    errors.append(f"素材 {material.id}：{exc}")
                    new_images.append(url)

            if changed:
                material.images = new_images
                touched += 1
                await self.session.commit()

        return {
            "mode": mode,
            "materials": touched,
            "processed_images": processed_images,
            "skipped_images": skipped_images,
            "failed_images": failed,
            "errors": errors[:20],
            "settings": {
                "content": settings["content"],
                "font_size": settings["font_size"],
                "color": "#%02X%02X%02X" % settings["color"],
                "opacity": settings["opacity"],
                "rotation": settings["rotation"],
                "position": settings["position"],
            },
        }

    async def remove_watermark(
        self,
        current_user: User,
        ids: list[int],
        *,
        is_admin: bool = False,
    ) -> dict[str, Any]:
        """去水印（AI 接口半成品）。

        目前只做两件事：
        1. 校验素材与图片是否存在（便于前端提示）
        2. 检查是否配置了 AI 去水印接口；未配置时返回明确的未开放提示
        """
        if not ids:
            raise WatermarkError("请先选择素材")
        if len(ids) > MAX_MATERIALS_PER_REQUEST:
            raise WatermarkError(f"单次最多处理 {MAX_MATERIALS_PER_REQUEST} 条素材，请分批操作")

        settings = await self.load_settings()
        materials = await self._load_materials(ids, current_user.id, is_admin)
        if not materials:
            raise WatermarkError("没有找到可处理的素材")

        total_images = sum(len(m.images or []) for m in materials)
        if not settings["ai_remove_url"]:
            return {
                "ready": False,
                "images": total_images,
                "message": "去水印功能需要先配置 AI 图像处理接口，当前版本暂未开放",
            }

        return {
            "ready": False,
            "images": total_images,
            "message": "AI 去水印接口协议尚未接入完成，当前版本暂不可用",
        }
